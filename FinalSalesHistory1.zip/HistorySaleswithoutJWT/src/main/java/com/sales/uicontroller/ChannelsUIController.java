package com.sales.uicontroller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sales.entities.Channels;

import com.sales.exception.NotFoundException;
import com.sales.services.ChannelsService;

import java.util.*;


@Controller
@RequestMapping("/api/ui/channels")
public class ChannelsUIController {

	@Autowired
	private ChannelsService channelsService;

	@GetMapping("/all")
	public String getAllCountries(Model model) {
		List<Channels> channels = channelsService.getAllChannels();
		model.addAttribute("channels", channels);
		return "allChannels";
	}


	@RequestMapping(method = RequestMethod.GET, value = "/delete/{id}")

	public String getCountriesAddForm(@PathVariable("id") int id) throws NotFoundException {

		System.out.println(id);

		channelsService.deleteChannels(id);

		return "redirect:/api/ui/channels/all";
	}

	@GetMapping("/add")
	public String getChannelsAddForm(Model model) {
		Channels channels = new Channels();
		channels.setChannelId(12343); // You can set default values here if needed
		model.addAttribute("newChannels", channels);
		return "addChannels";
	}

	@PostMapping("/add")
	public String addNewChannel(@ModelAttribute("newChannels") Channels channels) {
		channelsService.createChannels(channels);
		return "redirect:/api/ui/channels/all";
	}

	@GetMapping("/view/{channelId}")
	public String getChannelsById(Model model, @PathVariable("channelId") int channelId) throws NotFoundException {
		Channels channel = channelsService.getChannelsById(channelId);
		model.addAttribute("channel", channel);
		return "oneChannel";
	}

	@GetMapping("/update/{channelId}")
	public String getUpdateChannelsForm(@PathVariable("channelId") int channelId, Model model) throws NotFoundException {
		// Retrieve the department data for the form
		Channels channel = channelsService.getChannelsById(channelId);
		// Populate the model with the department data
		model.addAttribute("updatedChannel", channel);
		return "updateChannel"; // Return the view template
	}



	// Handle form submission
	@PostMapping("/update/{channelId}")
	public String updateChannel( @ModelAttribute("updatedChannel") Channels updatedChannel,
			Model model) {
		try {
			// You should validate and sanitize the input here if needed
			// Then, update the department
			channelsService.updateChannels(updatedChannel);
			return "redirect:/api/ui/channels/all"; // Redirect to the channels list page
		} catch (NotFoundException e) {
			// Handle the exception, e.g., show an error message
			return "error"; // Create an error template
		}
	}






	/*
	 * @GetMapping("/update") public String getChannelsUpdateForm(Model model) {
	 * ChannelsService.update return "redirect:/api/ui/channels/all"; }
	 */
}
