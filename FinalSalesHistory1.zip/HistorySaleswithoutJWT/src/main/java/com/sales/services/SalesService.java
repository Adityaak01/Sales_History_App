package com.sales.services;

import java.util.*;

import com.sales.entities.Sales;




public interface SalesService {

	List<Sales> getAllSales();

	List<Sales> getSalesByQuarter(int month);

	List<Sales> getSalesByDate(Date date);

	List<Object[]> getSalesByCategory();

	List<Object[]> getSalesByCategoryYearWise(int year);

	List<Object[]> getAmountSoldForSalesByCategories();

	List<Object[]> getAmountSoldForSalesByCategoriesYearWise(int year);




}
