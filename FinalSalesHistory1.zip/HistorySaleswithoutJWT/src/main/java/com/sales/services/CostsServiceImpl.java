package com.sales.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sales.entities.*;
import com.sales.exception.NotFoundException;
import com.sales.repository.CostRepository;


public class CostsServiceImpl implements CostsService {


	@Autowired

	CostRepository costsRepository;


	@Override

	public Cost getCostById(int costsId) throws NotFoundException{



		if(costsRepository.findById(costsId).isEmpty())



			throw new NotFoundException("The Product with"+costsId+"does not exists");



		return costsRepository.findById(costsId).get();

	}


	@Override

	public List<Cost> getAllCosts() {


		return costsRepository.findAll();

	}



	@Override

	public void createCosts(Cost costs) {


		costsRepository.save(costs);


	}

	@Override

	public Cost updateCosts(Cost costs)throws NotFoundException {

		if(costsRepository.findById(costs.getCostId()).isEmpty())

			throw new NotFoundException("The costs with"+costs.getCostId()+"does not exists");

		return costsRepository.save(costs);


	}

	@Override

	public void deleteCosts(int costsId) throws NotFoundException{

		if(costsRepository.findById(costsId).isEmpty())

			throw new NotFoundException("The Product with"+costsId+"does not exists");

	}


}