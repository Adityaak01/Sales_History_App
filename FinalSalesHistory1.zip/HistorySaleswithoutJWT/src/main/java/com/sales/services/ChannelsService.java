package com.sales.services;

import java.util.*;

import com.sales.entities.Channels;
import com.sales.exception.NotFoundException;


public interface ChannelsService {

	Channels getChannelsById(int ChannelsId) throws NotFoundException;

	List<Channels> getAllChannels();

	void createChannels(Channels Channels);

	Channels updateChannels(Channels Channels) throws NotFoundException;

	void deleteChannels(int ChannelsId) throws NotFoundException;

	Channels saveChannels(Channels channels);



}
