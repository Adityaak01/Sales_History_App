package com.sales.services;

import java.util.*;

import org.springframework.stereotype.Service;

import com.sales.entities.Customers;
import com.sales.exception.NotFoundException;


public interface CustomersService {

	Customers getCustomersById(int customerId) throws NotFoundException;

	List<Customers> getAllCustomers();

	void createCustomers(Customers customers);

	Customers updateCustomers(Customers customers) throws NotFoundException;

	void deleteCustomers(int customerId) throws NotFoundException;

	List<Customers> searchCustomersByFirstName(String CustomerFirstName) throws NotFoundException;

	List<Customers> searchCustomersByCity(String customerCity) throws NotFoundException;

	List<Customers> searchCustomersByIncome(String customerIncomeLevel) throws NotFoundException;

	List<Customers> searchCustomersBetweenCreditLimit(int minCreditLimit, int maxCreditLimit) throws NotFoundException;

	Customers updateCustomerCreditLimit(int customerId, int newCreditLimit) throws NotFoundException;




}
