package com.sales.services;

import java.util.*;
import com.sales.entities.Cost;
import com.sales.exception.NotFoundException;



public interface CostsService {



	Cost getCostById(int costsId) throws NotFoundException;



	List<Cost> getAllCosts();



	void createCosts(Cost costs);



	Cost updateCosts(Cost costs) throws NotFoundException;



	void deleteCosts(int costsId) throws NotFoundException;



}