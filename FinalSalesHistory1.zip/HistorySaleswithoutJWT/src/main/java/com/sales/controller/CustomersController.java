package com.sales.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sales.entities.Countries;
import com.sales.entities.Customers;
import com.sales.exception.InvalidDataException;
import com.sales.services.CustomersService;
import com.sales.exception.NotFoundException;

//saleshistoryapp database


@Controller
@RequestMapping("/api/v1/Customers")
public class CustomersController {
	@Autowired
	CustomersService customersService;

	public CustomersController(CustomersService customersService2) {
		// TODO Auto-generated constructor stub
	}

	@GetMapping("/all")
	public ResponseEntity<List<Customers>> getAllCustomers(){
		return new ResponseEntity<List<Customers>>(customersService.getAllCustomers(), HttpStatus.OK);
	}

	@PostMapping("/create")
	public ResponseEntity<Void> createCustomers(@RequestBody Customers customers){
		customersService.createCustomers(customers);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@PutMapping("/edit")
	public ResponseEntity<Customers> updateCustomers(@RequestBody Customers customers) throws NotFoundException{
		customersService.updateCustomers(customers);
		return new ResponseEntity<Customers>(HttpStatus.OK);//OK for successful update operation
	}
	@DeleteMapping("/delete/{customerId}")
	public ResponseEntity<Void> deleteCustomers(@PathVariable int customerId) throws NotFoundException {
		customersService.deleteCustomers(customerId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Use NO_CONTENT for successful DELETE
	}


	@GetMapping("/firstName/{CustomerFirstName}")

	public ResponseEntity<List<Customers>> searchCustomersByFirstName(@PathVariable("CustomerFirstName") String CustomerFirstName) throws NotFoundException{

		if (customersService.searchCustomersByFirstName(CustomerFirstName).isEmpty()) {
			throw new NotFoundException("Cannot find customer with FirstName "+CustomerFirstName);
		} else {
			List<Customers> cust = customersService.searchCustomersByFirstName(CustomerFirstName);
			return new ResponseEntity<>(cust,HttpStatus.OK);
		}

	}


	@GetMapping("/city/{customerCity}")

	public ResponseEntity<List<Customers>> searchCustomersByCity(@PathVariable("customerCity") String customerCity) throws NotFoundException{

		if (customersService.searchCustomersByCity(customerCity).isEmpty()) {
			throw new NotFoundException("Cannot find customer with city "+customerCity);
		} else {
			List<Customers> cust = customersService.searchCustomersByCity(customerCity);
			return new ResponseEntity<>(cust,HttpStatus.OK);
		}
	}


	@GetMapping("/income/{customerIncomeLevel}")

	public ResponseEntity<List<Customers>> searchCustomersByIncome(@PathVariable("customerIncomeLevel") String customerIncomeLevel) throws NotFoundException{

		if (customersService.searchCustomersByIncome(customerIncomeLevel).isEmpty()){
			throw new NotFoundException("Cannot find customer with incomeLevel "+customerIncomeLevel);
		} else {
			List<Customers> cust = customersService.searchCustomersByIncome(customerIncomeLevel);
			return new ResponseEntity<>(cust,HttpStatus.OK);
		}




	}



	@GetMapping("/creditLimit/{minCreditLimit}/{maxCreditLimit}")
	public ResponseEntity<List<Customers>> findCustomersByCreditlimit(@PathVariable("minCreditLimit") int minCreditLimit,@PathVariable("maxCreditLimit") int maxCreditLimit) throws NotFoundException {

		if (customersService.searchCustomersBetweenCreditLimit(minCreditLimit, maxCreditLimit).isEmpty()){
			throw new NotFoundException("Cannot find customer with credit limit between "+minCreditLimit +" and "+maxCreditLimit);
		} else {
			List<Customers> cust = customersService.searchCustomersBetweenCreditLimit(minCreditLimit, maxCreditLimit);
			return new ResponseEntity<>(cust,HttpStatus.OK);
		}



	}





	@PutMapping("/{customerId}/{newCreditLimit}")

	public ResponseEntity<Customers> updateCustomerCreditLimit(@PathVariable("customerId") int customerId, @PathVariable("newCreditLimit") int newCreditLimit) throws NotFoundException{

		return new ResponseEntity<Customers>(customersService.updateCustomerCreditLimit(customerId, newCreditLimit),HttpStatus.OK);

	}

}
