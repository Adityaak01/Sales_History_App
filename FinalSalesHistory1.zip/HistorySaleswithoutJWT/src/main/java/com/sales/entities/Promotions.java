package com.sales.entities;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PROMOTIONS")
public class Promotions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PROMO_ID")
    private int promoId;

 

    @Column(name = "PROMO_NAME", length = 30)
    private String promoName;

 

    @Column(name = "PROMO_SUBCATEGORY", length = 30)
    private String promoSubcategory;

 

    @Column(name = "PROMO_SUBCATEGORY_ID")
    private int promoSubcategoryId;

 

    @Column(name = "PROMO_CATEGORY", length = 30)
    private String promoCategory;

 

    @Column(name = "PROMO_CATEGORY_ID")
    private int promoCategoryId;

 

    @Column(name = "PROMO_COST", precision = 10, scale = 2)
    private BigDecimal promoCost;

 

    @Column(name = "PROMO_BEGIN_DATE")
    private Date promoBeginDate;

 

    @Column(name = "PROMO_END_DATE")
    private Date promoEndDate;

 

    @Column(name = "PROMO_TOTAL", length = 15)
    private String promoTotal;

 

    @Column(name = "PROMO_TOTAL_ID")
    private int promoTotalId;
    
    @OneToMany(mappedBy = "promotions", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Sales> sales;

	@OneToMany(mappedBy = "promotions", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Cost> costs;

	
	
	


	public Promotions(int promoId, String promoName, String promoSubcategory, int promoSubcategoryId,
			String promoCategory, int promoCategoryId, BigDecimal promoCost, Date promoBeginDate, Date promoEndDate,
			String promoTotal, int promoTotalId, List<Sales> sales, List<Cost> costs) {
		super();
		this.promoId = promoId;
		this.promoName = promoName;
		this.promoSubcategory = promoSubcategory;
		this.promoSubcategoryId = promoSubcategoryId;
		this.promoCategory = promoCategory;
		this.promoCategoryId = promoCategoryId;
		this.promoCost = promoCost;
		this.promoBeginDate = promoBeginDate;
		this.promoEndDate = promoEndDate;
		this.promoTotal = promoTotal;
		this.promoTotalId = promoTotalId;
		this.sales = sales;
		this.costs = costs;
		
	}
	
	



	public Promotions() {
		super();
	}





	public int getPromoId() {
		return promoId;
	}



	public void setPromoId(int promoId) {
		this.promoId = promoId;
	}



	public String getPromoName() {
		return promoName;
	}



	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}





	public String getPromoSubcategory() {
		return promoSubcategory;
	}



	public void setPromoSubcategory(String promoSubcategory) {
		this.promoSubcategory = promoSubcategory;
	}



	public int getPromoSubcategoryId() {
		return promoSubcategoryId;
	}



	public void setPromoSubcategoryId(int promoSubcategoryId) {
		this.promoSubcategoryId = promoSubcategoryId;
	}



	public String getPromoCategory() {
		return promoCategory;
	}



	public void setPromoCategory(String promoCategory) {
		this.promoCategory = promoCategory;
	}



	public int getPromoCategoryId() {
		return promoCategoryId;
	}



	public void setPromoCategoryId(int promoCategoryId) {
		this.promoCategoryId = promoCategoryId;
	}



	public BigDecimal getPromoCost() {
		return promoCost;
	}



	public void setPromoCost(BigDecimal promoCost) {
		this.promoCost = promoCost;
	}



	public Date getPromoBeginDate() {
		return promoBeginDate;
	}



	public void setPromoBeginDate(Date promoBeginDate) {
		this.promoBeginDate = promoBeginDate;
	}



	public Date getPromoEndDate() {
		return promoEndDate;
	}



	public void setPromoEndDate(Date promoEndDate) {
		this.promoEndDate = promoEndDate;
	}



	public String getPromoTotal() {
		return promoTotal;
	}



	public void setPromoTotal(String promoTotal) {
		this.promoTotal = promoTotal;
	}



	public int getPromoTotalId() {
		return promoTotalId;
	}



	public void setPromoTotalId(int promoTotalId) {
		this.promoTotalId = promoTotalId;
	}



	public List<Sales> getSales() {
		return sales;
	}



	public void setSales(List<Sales> sales) {
		this.sales = sales;
	}



	public List<Cost> getCosts() {
		return costs;
	}



	public void setCosts(List<Cost> costs) {
		this.costs = costs;
	}





	@Override
	public String toString() {
		return "Promotions [promoId=" + promoId + ", promoName=" + promoName + ", promoSubcategory=" + promoSubcategory
				+ ", promoSubcategoryId=" + promoSubcategoryId + ", promoCategory=" + promoCategory
				+ ", promoCategoryId=" + promoCategoryId + ", promoCost=" + promoCost + ", promoBeginDate="
				+ promoBeginDate + ", promoEndDate=" + promoEndDate + ", promoTotal=" + promoTotal + ", promoTotalId="
				+ promoTotalId + ", sales=" + sales + ", costs=" + costs+ "]";
	}
	
	
	
	
    
    
}
