package com.sales.exception;

import org.springframework.validation.BindException;

public class ConstraintViolationException extends RuntimeException{

	 private final BindException bindingResult;
	 public ConstraintViolationException(BindException bindingResult) {
	        super("Validation errors occurred");
	        this.bindingResult = bindingResult;
	    }

	    public BindException getBindingResult() {
	        return bindingResult;
	    }

	
}


