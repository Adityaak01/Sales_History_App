package com.sales.exception;

import java.time.LocalDateTime;
import java.util.stream.Collectors;
import com.sales.dto.*;
import com.sales.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class MyRestGlobalExceptionHandler {
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleOtherExceptions(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred.");
    }
	
	@ExceptionHandler(NotFoundException.class)

	public ResponseEntity<ApiResponse>handleNotFoundException(NotFoundException ex){

		 ApiResponse response = new ApiResponse(ex.getMessage(), "Not Found");

	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

	    }

	@ExceptionHandler(InvalidDataException.class)

	public ResponseEntity<ApiResponse>handleInvalidDataException(InvalidDataException ex){

		 ApiResponse response = new ApiResponse(ex.getMessage(), "Invalid");

	        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

	    }
	
	@ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorInfo> handleConstraintViolationException(ConstraintViolationException ex) {
		ErrorInfo errorInfo = new ErrorInfo();

		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());

		String errorMsg = ex.getBindingResult().getAllErrors()

				.stream()

				.map(x -> x.getDefaultMessage())

				.collect(Collectors.joining(", "));

		errorInfo.setErrorMessage(errorMsg);

		errorInfo.setTimestamp(LocalDateTime.now());

		return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);

        
    }

	
	


}
