package com.sales.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sales.entities.Customers;
import com.sales.entities.Products;



public interface ProductsRepository extends JpaRepository<Products, Integer>{


	@Query("SELECT p FROM Products p WHERE p.productCategory= ?1")
	List<Products> findProductsByCategory(@Param("productCategory") String productCategory);

	@Query("SELECT p FROM Products p WHERE p.productStatus= ?1")
	List<Products> findProductsByStatus(@Param("productStatus") String productStatus);

	@Query("SELECT p FROM Products p WHERE p.productSubCategory= ?1")
	List<Products> findProductsBySubCategory(@Param("productSubCategory") String productSubCategory);

	@Query("SELECT p FROM Products p WHERE p.productSupplierId= ?1")
	List<Products> findProductsBySupplierId(@Param("productSupplierId") int productSupplierId);

	@Query("SELECT p FROM Products p WHERE p.productName IN (SELECT p2.productName FROM Products p2 GROUP BY p2.productName HAVING COUNT(p2.productName) > 1) ORDER BY p.productName")
	public List<Products> findDuplicateProductsByProductName();


	@Query("SELECT c.channelDescription, p, cu FROM Sales s JOIN s.channels c JOIN s.products p JOIN s.customers cu WHERE c.channelDescription = :channel")
	public List<Object[]> findProductsByChannelWiseSold(String channel);




}
