package com.sales.repository;

public interface SupplierRepository {

}
