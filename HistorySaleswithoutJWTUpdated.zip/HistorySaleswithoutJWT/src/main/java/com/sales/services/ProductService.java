package com.sales.services;
import java.util.*;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.sales.exception.NotFoundException;
import com.sales.entities.Products;

@Service
public interface ProductService {
	Products getProductById(int productId) throws NotFoundException;
	List<Products> getAllProducts();
	void createProducts(Products products);
	Products updateProducts(Products products) throws NotFoundException;
	void deleteProducts(int productId) throws NotFoundException;
	List<Products> searchProductsByCategory(String productCategory) throws NotFoundException;
	List<Products> searchProductsByStatus(String productStatus) throws NotFoundException;
	List<Products> searchProductsBySubCategory(String productSubCategory) throws NotFoundException;
	List<Products> searchProductsBySupplierId(int productSupplierId) throws NotFoundException;
	List<Products> searchDuplicateProductsByProductName() throws NotFoundException;

	List<Object[]> getProductsByChannelWiseSold(String channel);

	List<Products> getProductsOrderedByField(String field);

}
