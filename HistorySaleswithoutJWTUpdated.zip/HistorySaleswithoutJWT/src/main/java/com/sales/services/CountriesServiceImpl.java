package com.sales.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Countries;

import com.sales.exception.NotFoundException;
import com.sales.repository.CountriesRepository; 


@Service
public class CountriesServiceImpl implements CountriesService {	
	@Autowired
	CountriesRepository countriesRepository;



	public CountriesServiceImpl(CountriesRepository countriesRepository2) {
		// TODO Auto-generated constructor stub
	}



	@Override

	public Countries getCountriesById(int countryId) throws NotFoundException{

		if(countriesRepository.findById(countryId).isEmpty())

			throw new NotFoundException("The Countries with "+countryId+" does not exists");



		return countriesRepository.findById(countryId).get();

	}



	@Override

	public List<Countries> getAllCountries() {



		return countriesRepository.findAll();

	}



	@Override

	public void createCountries(Countries countries) {

		// TODO Auto-generated method stub

		countriesRepository.save(countries);

	}



	@Override

	public Countries updateCountries(Countries countries)throws NotFoundException {

		if(countriesRepository.findById(countries.getCountryId()).isEmpty())

			throw new NotFoundException("The Channel with "+countries.getCountryId()+" does not exists");



		return countriesRepository.save(countries);

	}



	@Override

	public void deleteCountries(int countryId) throws NotFoundException{

		if(countriesRepository.findById(countryId).isEmpty())

			throw new NotFoundException("The Countries with "+countryId+" does not exists");



	}



	@Override
	public List<Map<String, Object>> getCustomerCountByCountry() {
		return countriesRepository.getCustomerCountCountryWise();
	}

	@Override
	public List<Object[]> getCustomerCountByRegion(String countryRegion) {
		return countriesRepository.getCustomerCountRegionWise(countryRegion);
	}


}