package com.sales.entities;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "CUSTOMERS")
public class Customers {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CUST_ID")
    private int customerId;

    @NotBlank(message = "Customer first name is required")
    @Column(name = "CUST_FIRST_NAME")
    private String CustomerFirstName;
 
    @Column(name = "CUST_LAST_NAME")
    private String customerLastName;
 
    @Column(name = "CUST_GENDER")
    private char customerGender;
 
    @Column(name = "CUST_YEAR_OF_BIRTH")
    private int customerYearOfBirth;
 
    @Column(name = "CUST_MARITAL_STATUS")
    private String customerMaritalStatus;
 
    @Column(name = "CUST_STREET_ADDRESS")
    private String customerStreetAddress;
 
    @Column(name = "CUST_POSTAL_CODE")
    private String customerPostalCode;
 
    @Column(name = "CUST_CITY")
    private String customerCity;
 
    @Column(name = "CUST_CITY_ID")
    private int customerCityId;
 
    @Column(name = "CUST_STATE_PROVINCE")
    private String customerStateProvince;
 
    @Column(name = "CUST_STATE_PROVINCE_ID")
    private int customerStateProvinceId;
 
 
    @Column(name = "CUST_MAIN_PHONE_INT")
    private String customerMainPhone;
 
    @Column(name = "CUST_INCOME_LEVEL")
    private String customerIncomeLevel;
 
    @Min(value = 0, message = "Customer credit limit cannot be negative")
    @Column(name = "CUST_CREDIT_LIMIT")
    private int customerCreditLimit;
 
    @Email(message = "Invalid email format")
    @Column(name = "CUST_EMAIL")
    private String customerEmail;
 
    @Column(name = "CUST_TOTAL")
    private String customerTotal;
 
    @Column(name = "CUST_TOTAL_ID")
    private int customerTotalId;
 
    @Column(name = "CUST_SRC_ID")
    private Integer customerSrcId;
 
    @Column(name = "CUST_EFF_FROM")
    private Date customerEffFrom;
 
    @Column(name = "CUST_EFF_TO")
    private Date customerEffTo;
 
    @Column(name = "CUST_VALID")
    private char customerValid;
    
    @Column(name="CUST_MAIN_PHONE_NUMBER")
    private String customerMainPhoneNumber;
    
    @ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "COUNTRY_ID")
    @JsonIgnore
	private Countries countries; 

    @JsonIgnore
	@OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Sales> sales;
	


	public Customers(int customerId, String customerFirstName, String customerLastName, char customerGender,
			int customerYearOfBirth, String customerMaritalStatus, String customerStreetAddress,
			String customerPostalCode, String customerCity, int customerCityId, String customerStateProvince,
			int customerStateProvinceId, String customerMainPhone, String customerIncomeLevel, int customerCreditLimit,
			String customerEmail, String customerTotal, int customerTotalId, Integer customerSrcId,
			Date customerEffFrom, Date customerEffTo, char customerValid, String customerMainPhoneNumber,
			Countries countries, List<Sales> sales) {
		super();
		this.customerId = customerId;
		CustomerFirstName = customerFirstName;
		this.customerLastName = customerLastName;
		this.customerGender = customerGender;
		this.customerYearOfBirth = customerYearOfBirth;
		this.customerMaritalStatus = customerMaritalStatus;
		this.customerStreetAddress = customerStreetAddress;
		this.customerPostalCode = customerPostalCode;
		this.customerCity = customerCity;
		this.customerCityId = customerCityId;
		this.customerStateProvince = customerStateProvince;
		this.customerStateProvinceId = customerStateProvinceId;
		this.customerMainPhone = customerMainPhone;
		this.customerIncomeLevel = customerIncomeLevel;
		this.customerCreditLimit = customerCreditLimit;
		this.customerEmail = customerEmail;
		this.customerTotal = customerTotal;
		this.customerTotalId = customerTotalId;
		this.customerSrcId = customerSrcId;
		this.customerEffFrom = customerEffFrom;
		this.customerEffTo = customerEffTo;
		this.customerValid = customerValid;
		this.customerMainPhoneNumber = customerMainPhoneNumber;
		this.countries = countries;
		this.sales = sales;
	}
	


	public Customers() {
		super();
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}






	public String getCustomerFirstName() {
		return CustomerFirstName;
	}



	public void setCustomerFirstName(String customerFirstName) {
		CustomerFirstName = customerFirstName;
	}


	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}


	public char getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(char customerGender) {
		this.customerGender = customerGender;
	}

	public int getCustomerYearOfBirth() {
		return customerYearOfBirth;
	}






	public void setCustomerYearOfBirth(int customerYearOfBirth) {
		this.customerYearOfBirth = customerYearOfBirth;
	}






	public String getCustomerMaritalStatus() {
		return customerMaritalStatus;
	}






	public void setCustomerMaritalStatus(String customerMaritalStatus) {
		this.customerMaritalStatus = customerMaritalStatus;
	}






	public String getCustomerStreetAddress() {
		return customerStreetAddress;
	}






	public void setCustomerStreetAddress(String customerStreetAddress) {
		this.customerStreetAddress = customerStreetAddress;
	}






	public String getCustomerPostalCode() {
		return customerPostalCode;
	}






	public void setCustomerPostalCode(String customerPostalCode) {
		this.customerPostalCode = customerPostalCode;
	}






	public String getCustomerCity() {
		return customerCity;
	}






	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}






	public int getCustomerCityId() {
		return customerCityId;
	}






	public void setCustomerCityId(int customerCityId) {
		this.customerCityId = customerCityId;
	}






	public String getCustomerStateProvince() {
		return customerStateProvince;
	}






	public void setCustomerStateProvince(String customerStateProvince) {
		this.customerStateProvince = customerStateProvince;
	}






	public int getCustomerStateProvinceId() {
		return customerStateProvinceId;
	}






	public void setCustomerStateProvinceId(int customerStateProvinceId) {
		this.customerStateProvinceId = customerStateProvinceId;
	}






	public String getCustomerMainPhone() {
		return customerMainPhone;
	}






	public void setCustomerMainPhone(String customerMainPhone) {
		this.customerMainPhone = customerMainPhone;
	}






	public String getCustomerIncomeLevel() {
		return customerIncomeLevel;
	}






	public void setCustomerIncomeLevel(String customerIncomeLevel) {
		this.customerIncomeLevel = customerIncomeLevel;
	}






	public int getCustomerCreditLimit() {
		return customerCreditLimit;
	}






	public void setCustomerCreditLimit(int customerCreditLimit) {
		this.customerCreditLimit = customerCreditLimit;
	}






	public String getCustomerEmail() {
		return customerEmail;
	}






	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}






	public String getCustomerTotal() {
		return customerTotal;
	}






	public void setCustomerTotal(String customerTotal) {
		this.customerTotal = customerTotal;
	}






	public int getCustomerTotalId() {
		return customerTotalId;
	}






	public void setCustomerTotalId(int customerTotalId) {
		this.customerTotalId = customerTotalId;
	}






	public Integer getCustomerSrcId() {
		return customerSrcId;
	}






	public void setCustomerSrcId(Integer customerSrcId) {
		this.customerSrcId = customerSrcId;
	}






	public Date getCustomerEffFrom() {
		return customerEffFrom;
	}






	public void setCustomerEffFrom(Date customerEffFrom) {
		this.customerEffFrom = customerEffFrom;
	}






	public Date getCustomerEffTo() {
		return customerEffTo;
	}






	public void setCustomerEffTo(Date customerEffTo) {
		this.customerEffTo = customerEffTo;
	}






	public char getCustomerValid() {
		return customerValid;
	}






	public void setCustomerValid(char customerValid) {
		this.customerValid = customerValid;
	}






	public String getCustomerMainPhoneNumber() {
		return customerMainPhoneNumber;
	}






	public void setCustomerMainPhoneNumber(String customerMainPhoneNumber) {
		this.customerMainPhoneNumber = customerMainPhoneNumber;
	}






	public Countries getCountries() {
		return countries;
	}






	public void setCountries(Countries countries) {
		this.countries = countries;
	}






	public List<Sales> getSales() {
		return sales;
	}






	public void setSales(List<Sales> sales) {
		this.sales = sales;
	}


	@Override
	public String toString() {
		return "Customers [customerId=" + customerId + ", CustomerFirstName=" + CustomerFirstName
				+ ", customerLastName=" + customerLastName + ", customerGender=" + customerGender
				+ ", customerYearOfBirth=" + customerYearOfBirth + ", customerMaritalStatus=" + customerMaritalStatus
				+ ", customerStreetAddress=" + customerStreetAddress + ", customerPostalCode=" + customerPostalCode
				+ ", customerCity=" + customerCity + ", customerCityId=" + customerCityId + ", customerStateProvince="
				+ customerStateProvince + ", customerStateProvinceId=" + customerStateProvinceId
				+ ", customerMainPhone=" + customerMainPhone + ", customerIncomeLevel=" + customerIncomeLevel
				+ ", customerCreditLimit=" + customerCreditLimit + ", customerEmail=" + customerEmail
				+ ", customerTotal=" + customerTotal + ", customerTotalId=" + customerTotalId + ", customerSrcId="
				+ customerSrcId + ", customerEffFrom=" + customerEffFrom + ", customerEffTo=" + customerEffTo
				+ ", customerValid=" + customerValid + ", customerMainPhoneNumber=" + customerMainPhoneNumber
				+ ", countries=" + countries + ", sales=" + sales + "]";
	}






	
    
}