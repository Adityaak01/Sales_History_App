package com.sales.entities;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "PRODUCTS")
public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PROD_ID")
    private int productId;

    @Column(name = "PROD_NAME")
    private String productName;

    @Size(max = 4000, message = "Product description must be at most 4000 characters")
    @Column(name = "PROD_DESC", length = 4000)
    private String productDescription;

    @Column(name = "PROD_SUBCATEGORY")
    private String productSubCategory;

    @Column(name = "PROD_SUBCATEGORY_ID")
    private int productSubCategoryId;

    @Size(max = 2000, message = "Product subcategory description must be at most 2000 characters")
    @Column(name = "PROD_SUBCATEGORY_DESC", length = 2000)
    private String productSubCategoryDescription;

    @Column(name = "PROD_CATEGORY")
    private String productCategory;

    @Column(name = "PROD_CATEGORY_ID")
    private int productCategoryId;

    @Size(max = 2000, message = "Product category description must be at most 2000 characters")
    @Column(name = "PROD_CATEGORY_DESC", length = 2000)
    private String productCategoryDescription;

    @Column(name = "PROD_WEIGHT_CLASS")
    private int productWeightClass;

    @Column(name = "PROD_UNIT_OF_MEASURE")
    private String productUnitOfMeasure;

    @Column(name = "PROD_PACK_SIZE")
    private String productPackSize;

    @Column(name = "PROD_SUPPLIER_ID")
    private Integer productSupplierId;

    @Column(name = "PROD_STATUS")
    private String productStatus;

    @DecimalMin(value = "0.00", message = "Product list price cannot be negative")
    @DecimalMax(value = "9999999.99", message = "Product list price cannot exceed 9,999,999.99")
    @Column(name = "PROD_LIST_PRICE", precision = 8, scale = 2)
    private BigDecimal productListPrice;

    @DecimalMin(value = "0.00", message = "Product minimum price cannot be negative")
    @DecimalMax(value = "9999999.99", message = "Product minimum price cannot exceed 9,999,999.99")
    @Column(name = "PROD_MIN_PRICE", precision = 8, scale = 2)
    private BigDecimal productMinPrice;

    @Size(max = 13, message = "Product total must be at most 13 characters")
    @Column(name = "PROD_TOTAL", length = 13)
    private String productTotal;

    @Column(name = "PROD_TOTAL_ID")
    private int productTotalId;

    @Column(name = "PROD_SRC_ID")
    private Integer productSrcId;

    @Column(name = "PROD_EFF_FROM")
    private Date productEffFrom;

    @Column(name = "PROD_EFF_TO")
    private Date productEffTo;

    @Column(name = "PROD_VALID")
    private char productValid;
    
    
    @OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JsonIgnore
	private List<Sales> sales;

   
	@OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Cost> costs;
	
	
	

	

	public Products(int productId, String productName, String productDescription, String productSubCategory,
			int productSubCategoryId, String productSubCategoryDescription, String productCategory,
			int productCategoryId, String productCategoryDescription, int productWeightClass,
			String productUnitOfMeasure, String productPackSize, int productSupplierId, String productStatus,
			BigDecimal productListPrice, BigDecimal productMinPrice, String productTotal, int productTotalId,
			int productSrcId, Date productEffFrom, Date productEffTo, char productValid, List<Sales> sales,
			List<Cost> costs) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productSubCategory = productSubCategory;
		this.productSubCategoryId = productSubCategoryId;
		this.productSubCategoryDescription = productSubCategoryDescription;
		this.productCategory = productCategory;
		this.productCategoryId = productCategoryId;
		this.productCategoryDescription = productCategoryDescription;
		this.productWeightClass = productWeightClass;
		this.productUnitOfMeasure = productUnitOfMeasure;
		this.productPackSize = productPackSize;
		this.productSupplierId = productSupplierId;
		this.productStatus = productStatus;
		this.productListPrice = productListPrice;
		this.productMinPrice = productMinPrice;
		this.productTotal = productTotal;
		this.productTotalId = productTotalId;
		this.productSrcId = productSrcId;
		this.productEffFrom = productEffFrom;
		this.productEffTo = productEffTo;
		this.productValid = productValid;
		this.sales = sales;
		this.costs = costs;
		
	}
	
	

	public Products() {
		super();
	}




	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductSubCategory() {
		return productSubCategory;
	}

	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}

	public int getProductSubCategoryId() {
		return productSubCategoryId;
	}

	public void setProductSubCategoryId(int productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}

	public String getProductSubCategoryDescription() {
		return productSubCategoryDescription;
	}

	public void setProductSubCategoryDescription(String productSubCategoryDescription) {
		this.productSubCategoryDescription = productSubCategoryDescription;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getProductCategoryId() {
		return productCategoryId;
	}

	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}

	public String getProductCategoryDescription() {
		return productCategoryDescription;
	}

	public void setProductCategoryDescription(String productCategoryDescription) {
		this.productCategoryDescription = productCategoryDescription;
	}

	public int getProductWeightClass() {
		return productWeightClass;
	}

	public void setProductWeightClass(int productWeightClass) {
		this.productWeightClass = productWeightClass;
	}

	public String getProductUnitOfMeasure() {
		return productUnitOfMeasure;
	}

	public void setProductUnitOfMeasure(String productUnitOfMeasure) {
		this.productUnitOfMeasure = productUnitOfMeasure;
	}

	public String getProductPackSize() {
		return productPackSize;
	}

	public void setProductPackSize(String productPackSize) {
		this.productPackSize = productPackSize;
	}

	public int getProductSupplierId() {
		return productSupplierId;
	}

	public void setProductSupplierId(int productSupplierId) {
		this.productSupplierId = productSupplierId;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public BigDecimal getProductListPrice() {
		return productListPrice;
	}

	public void setProductListPrice(BigDecimal productListPrice) {
		this.productListPrice = productListPrice;
	}

	public BigDecimal getProductMinPrice() {
		return productMinPrice;
	}

	public void setProductMinPrice(BigDecimal productMinPrice) {
		this.productMinPrice = productMinPrice;
	}

	public String getProductTotal() {
		return productTotal;
	}

	public void setProductTotal(String productTotal) {
		this.productTotal = productTotal;
	}

	public int getProductTotalId() {
		return productTotalId;
	}

	public void setProductTotalId(int productTotalId) {
		this.productTotalId = productTotalId;
	}

	public int getProductSrcId() {
		return productSrcId;
	}

	public void setProductSrcId(int productSrcId) {
		this.productSrcId = productSrcId;
	}

	public Date getProductEffFrom() {
		return productEffFrom;
	}

	public void setProductEffFrom(Date customerEffFrom) {
		this.productEffFrom = productEffFrom;
	}

	public Date getProductEffTo() {
		return productEffTo;
	}

	public void setProductEffTo(Date customerEffTo) {
		this.productEffTo = productEffTo;
	}

	public char getProductValid() {
		return productValid;
	}

	public void setProductValid(char productValid) {
		this.productValid = productValid;
	}

	public List<Sales> getSales() {
		return sales;
	}

	public void setSales(List<Sales> sales) {
		this.sales = sales;
	}

	public List<Cost> getCosts() {
		return costs;
	}

	public void setCosts(List<Cost> costs) {
		this.costs = costs;
	}

	@Override
	public String toString() {
		return "Products [productId=" + productId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", productSubCategory=" + productSubCategory + ", productSubCategoryId="
				+ productSubCategoryId + ", productSubCategoryDescription=" + productSubCategoryDescription
				+ ", productCategory=" + productCategory + ", productCategoryId=" + productCategoryId
				+ ", productCategoryDescription=" + productCategoryDescription + ", productWeightClass="
				+ productWeightClass + ", productUnitOfMeasure=" + productUnitOfMeasure + ", productPackSize="
				+ productPackSize + ", productSupplierId=" + productSupplierId + ", productStatus=" + productStatus
				+ ", productListPrice=" + productListPrice + ", productMinPrice=" + productMinPrice + ", productTotal="
				+ productTotal + ", productTotalId=" + productTotalId + ", productSrcId=" + productSrcId
				+ ", productEffFrom=" + productEffFrom + ", customerEffTo=" + productEffTo + ", productValid="
				+ productValid + ", sales=" + sales + ", costs=" + costs + ", supplier=" + "]";
	}


	

}