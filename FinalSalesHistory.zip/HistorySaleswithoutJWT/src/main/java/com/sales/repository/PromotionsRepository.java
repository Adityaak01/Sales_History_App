package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entities.Promotions;

public interface PromotionsRepository extends JpaRepository<Promotions, Integer>{

}
