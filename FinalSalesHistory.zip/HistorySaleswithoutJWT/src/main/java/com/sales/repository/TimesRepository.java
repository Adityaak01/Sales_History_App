package com.sales.repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entities.Times;

public interface TimesRepository extends JpaRepository<Times, Date>{

}
