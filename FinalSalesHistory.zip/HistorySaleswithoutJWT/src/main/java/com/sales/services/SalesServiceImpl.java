package com.sales.services;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sales.entities.Sales;
import com.sales.repository.SalesRepository;

@Service
public class SalesServiceImpl implements SalesService {	
	@Autowired
	SalesRepository salesRepository;


	@Override

	public List<Sales> getAllSales() {		

		return salesRepository.findAll();

	}



	@Override
	public List<Sales> getSalesByQuarter(int month) {
		return salesRepository.findAllSalesByQuarter(month);
	}

	@Override
	public List<Sales> getSalesByDate(Date date) {
		return salesRepository.findByDate(date);
	}

	@Override
	public List<Object[]> getSalesByCategory() {
		return salesRepository.findSalesQuantitySoldByCategory();
	}

	@Override
	public List<Object[]> getSalesByCategoryYearWise(int year) {
		return salesRepository.findSalesQuantitySoldByCategoryYearWise(year);
	}

	@Override
	public List<Object[]> getAmountSoldForSalesByCategories() {
		return salesRepository.findAmountSoldForSalesByCategories();
	}

	@Override
	public List<Object[]> getAmountSoldForSalesByCategoriesYearWise(int year) {
		return salesRepository.findAmountSoldForSalesByCategoriesYearWise(year);
	}



}