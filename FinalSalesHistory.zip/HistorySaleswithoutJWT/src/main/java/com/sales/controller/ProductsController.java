package com.sales.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sales.entities.Customers;
import com.sales.entities.Products;
import com.sales.services.ProductService;
import com.sales.exception.NotFoundException;



@Controller
@RequestMapping("/api/v1/Products")
public class ProductsController {
	@Autowired
	ProductService productService;

	@GetMapping(value="/all")
	public ResponseEntity<List<Products>> getAllProducts(){
		productService.getAllProducts().stream().forEach(System.out::print);
		return new ResponseEntity<List<Products>>(productService.getAllProducts(), HttpStatus.OK);
	}
	@PostMapping("/create")
	public ResponseEntity<Void> createProducts(@RequestBody Products products){
		productService.createProducts(products);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@PutMapping("/edit")
	public ResponseEntity<Products> updateProducts(@RequestBody Products products){
		return new ResponseEntity<Products>(HttpStatus.OK);
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<List<Products>> deleteProducts(@RequestBody Products products){
		return new ResponseEntity<List<Products>>(HttpStatus.NO_CONTENT);
	}

	@GetMapping("/category/{productCategory}")

	public ResponseEntity<List<Products>> searchProductsByCategory(@PathVariable("productCategory") String productCategory) throws NotFoundException{

		List <Products> product = 	productService.searchProductsByCategory(productCategory);

		return new ResponseEntity<>(product,HttpStatus.OK);
	}


	@GetMapping("/status/{productStatus}")

	public ResponseEntity<List<Products>> searchProductsByStatus(@PathVariable("productStatus") String productStatus) throws NotFoundException{

		List <Products> product = 	productService.searchProductsByStatus(productStatus);

		return new ResponseEntity<>(product,HttpStatus.OK);
	}


	@GetMapping("/subCategory/{productSubCategory}")

	public ResponseEntity<List<Products>> searchProductsBySubCategory(@PathVariable("productSubCategory") String productSubCategory) throws NotFoundException{

		List <Products> product = 	productService.searchProductsBySubCategory(productSubCategory);

		return new ResponseEntity<>(product,HttpStatus.OK);
	}

	@GetMapping("/supplierId/{productSupplierId}")

	public ResponseEntity<List<Products>> searchProductsBySupplierId(@PathVariable("productSupplierId") int productSupplierId) throws NotFoundException{

		List <Products> product = 	productService.searchProductsBySupplierId(productSupplierId);

		return new ResponseEntity<>(product,HttpStatus.OK);
	}

	@GetMapping("/duplicates")
	public ResponseEntity<List<Products>> searchDuplicatesProductsByProductName() throws NotFoundException {
		if (productService.searchDuplicateProductsByProductName().size() > 0) {
			List <Products> product = productService.searchDuplicateProductsByProductName();

			return new ResponseEntity<>(product,HttpStatus.OK);
		}
		else {
			throw new NotFoundException("Could not find any duplicate products.");
		}
	}

	@GetMapping("/channelWiseSold")
	public ResponseEntity<List<Object[]>> getProductByChannelWiseSold(@RequestParam("channel") String channel) {
		List<Object[]> list = productService.getProductsByChannelWiseSold(channel);
		if (list.size() == 0) {
			throw new NotFoundException("products not found with the given channel");
		}
		return new ResponseEntity<List<Object[]>>(list, HttpStatus.OK);
	}



	@GetMapping("/sort")
	public ResponseEntity<List<Products>> getProductsOrderedByField(@RequestParam("field") String field) {
		List<Products> products = productService.getProductsOrderedByField(field);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}


}
