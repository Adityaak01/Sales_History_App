package com.sales.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sales.entities.Products;
import com.sales.entities.Sales;
import com.sales.services.SalesService;
import com.sales.exception.NotFoundException;
/*
 * use saleshistoryapp database
 */

@Controller
@RequestMapping("/api/v1/Sales")
public class SalesController {

	@Autowired
	SalesService salesService;



	@GetMapping("/allSales")
	public ResponseEntity<List<Sales>> getAllSales(){

		return new ResponseEntity<List<Sales>>(salesService.getAllSales(), HttpStatus.OK);
	}

	@GetMapping("/quarter")
	public ResponseEntity<List<Sales>> gatAllSalesForQuarter(@RequestParam ("month") int month){
		if(salesService.getSalesByQuarter(month).isEmpty()){
			throw new NotFoundException("There are no sales in " +month+ " quarter");
		}else {
			return new ResponseEntity<List<Sales>>(salesService.getSalesByQuarter(month), HttpStatus.OK);

		}
	}

	@GetMapping("/date")
	public ResponseEntity<List<Sales>> getSalesByDate(@RequestParam("date") String dateString){
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = dateFormat.parse(dateString);

			List<Sales> list = salesService.getSalesByDate(date);
			if (list.isEmpty()) {
				throw new NotFoundException("There are no sales on " + dateString);
			} else {
				return new ResponseEntity<>(list, HttpStatus.OK);
			}
		} catch (ParseException e) {
			throw new IllegalArgumentException("Invalid date format. Please provide the date in yyyy-MM-dd format.");
		}
	}

	@GetMapping("/qtys/categorywise")
	public ResponseEntity<List<Object[]>>getSalesByCategory(){
		List<Object[]>list=salesService.getSalesByCategory();
		if(list.isEmpty()) {
			throw new NotFoundException("There are no sales by category");
		}
		else {
			return new ResponseEntity<List<Object[]>>(list,HttpStatus.OK);
		}
	}

	@GetMapping("/qtys/categorywise/year/{year}")
	public ResponseEntity<List<Object[]>> getCountOfQuantitiesByCategoryForYear(@PathVariable("year") int year){
		List<Object[]>list=salesService.getSalesByCategoryYearWise(year);
		if(list.isEmpty()) {
			throw new NotFoundException("There are no sales on "+year);
		}
		else {
			return new ResponseEntity<List<Object[]>>(list,HttpStatus.OK);
		}
	}

	@GetMapping("/sold/categorywise")
	public ResponseEntity<List<Object[]>> getAmountSoldForSalesByCategories(){
		List<Object[]>list=salesService.getAmountSoldForSalesByCategories();
		if(list.isEmpty()) {
			throw new NotFoundException("There are no amount sold by this categories");
		}
		else {
			return new ResponseEntity<List<Object[]>>(list,HttpStatus.OK);

		}
	}


	@GetMapping("/sold/categorywise/year/{year}")
	public ResponseEntity<List<Object[]>>  getAmountSoldForSalesByCategoriesYearWise(@PathVariable("year") int year){
		List<Object[]>list=salesService.getAmountSoldForSalesByCategoriesYearWise(year);
		if(list.isEmpty()) {
			throw new NotFoundException("There are no amount sold by this categories in year"+year);
		}
		else {
			return new ResponseEntity<List<Object[]>>(list,HttpStatus.OK);
		}

	}


}
