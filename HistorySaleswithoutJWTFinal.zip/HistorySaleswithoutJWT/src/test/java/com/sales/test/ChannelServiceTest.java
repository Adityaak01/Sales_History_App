package com.sales.test;


import com.sales.entities.Channels;

import com.sales.repository.ChannelsRepository;

import com.sales.services.ChannelsService;

import com.sales.services.ChannelsServiceImpl;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;

import org.mockito.MockitoAnnotations;

import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

import java.util.Optional;

 

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.*;

 

@ExtendWith(SpringExtension.class)

public class ChannelServiceTest {

    @Mock

    private ChannelsRepository channelsRepository;

    private ChannelsService channelsService;

 

    @BeforeEach

    void setUp() {

        MockitoAnnotations.initMocks(this);

        channelsService = new ChannelsServiceImpl(channelsRepository);

    }

 

//   @Test

//    void getAll_shouldReturnListOfChannels() {

//        // Arrange

//        List<Channels> expectedChannels = new ArrayList<>();

//        expectedChannels.add(new Channels(1, "Channel 1", "Class A", 1, "Total A", 101, null, null));

//        expectedChannels.add(new Channels(2, "Channel 2", "Class B", 2, "Total B", 102, null, null));

//

//        when(channelsRepository.findAll()).thenReturn(expectedChannels);

//

//        // Act

//        List<Channels> actualChannels = channelsService.getAll();

//

//        // Assert

//        assertEquals(expectedChannels.size(), actualChannels.size());

//        assertEquals(expectedChannels, actualChannels);

//    }

 

    @Test

    void getAll_shouldFailWhenRepositoryReturnsEmptyList() {

        // Arrange

        when(channelsRepository.findAll()).thenReturn(Collections.emptyList());

 

        // Act and Assert

        assertThrows(AssertionError.class, () -> {

            List<Channels> actualChannels = channelsService.getAllChannels();

            assertEquals(2, actualChannels.size());  // Expecting a different size than what is actually returned

        });

    }

 

    @Test

    void saveChannel_shouldSaveChannel() {

        // Arrange

        Channels channelToSave = new Channels(1, "Channel 1", "Class A", 1, "Total A", 101, null, null);

        when(channelsRepository.save(any(Channels.class))).thenReturn(channelToSave);

 

        // Act

        Channels savedChannel = channelsService.saveChannels(channelToSave);

 

        // Assert

        assertNotNull(savedChannel);

        assertEquals(channelToSave.getChannelId(), savedChannel.getChannelId());

    }

 

    @Test

    void saveChannel_shouldFailWhenRepositoryReturnsNull() {

        // Arrange

 

        // Act and Assert

        assertThrows(AssertionError.class, () -> {

            Channels savedChannel = channelsService.saveChannels(new Channels(1, "Test Channel", "Class", 3, "Total", 103, null, null));

            assertNotNull(savedChannel);  // Expecting a non-null saved channel

        });

    }

 

    @Test

    void updateChannel_shouldUpdateChannel() {

        // Arrange

        Channels existingChannel = new Channels(1, "Channel 1", "Class A", 1, "Total A", 101, null, null);

        when(channelsRepository.save(any(Channels.class))).thenReturn(existingChannel);

 

        // Act

        Channels updatedChannel = channelsService.updateChannels(existingChannel);

 

        // Assert

        assertNotNull(updatedChannel);

        assertEquals(existingChannel.getChannelId(), updatedChannel.getChannelId());

    }

 

    @Test

    void updateChannel_shouldFailWhenRepositoryReturnsNull() {

        // Arrange

        when(channelsRepository.save(any(Channels.class))).thenReturn(null);

 

        // Act and Assert

        assertThrows(AssertionError.class, () -> {

            Channels updatedChannel = channelsService.updateChannels(new Channels(1, "Updated Channel", "Class", 3, "Total", 103, null, null));

            assertNotNull(updatedChannel);  // Expecting a non-null updated channel

        });

    }

 

 

    @Test

    void deleteChannel_shouldDeleteChannel() {

        // Arrange

        int channelIdToDelete = 1;

        // Act

        assertDoesNotThrow(() -> channelsService.deleteChannels(channelIdToDelete));

        // Assert

        verify(channelsRepository, times(1)).deleteById(channelIdToDelete);

    }

 

    @Test

    void deleteChannel_shouldFailOnNonExistentChannel() {

        // Arrange

        int nonExistentChannelId = 0;

        when(channelsRepository.findById(nonExistentChannelId)).thenReturn(Optional.empty());

        // Act and Assert

        assertThrows(IllegalArgumentException.class, () -> channelsService.deleteChannels(nonExistentChannelId));

    }

 

}

 
