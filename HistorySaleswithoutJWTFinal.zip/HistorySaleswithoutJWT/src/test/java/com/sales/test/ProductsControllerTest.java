package com.sales.test;

import com.sales.controller.ProductsController;

import com.sales.entities.Products;
import com.sales.exception.InvalidDataException;
import com.sales.exception.NotFoundException;

import com.sales.services.ProductService;
import static org.hamcrest.Matchers.equalTo;

import org.assertj.core.api.Assert;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

 

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

 

public class ProductsControllerTest {

 

    @Mock

    private ProductService productService;

 

    @InjectMocks

    private ProductsController productsController;

 

    @BeforeEach

    void setUp() {

        MockitoAnnotations.openMocks(this); // Initialize the mocks and inject them into the controller

    }

 

    @Test

    void testGetAllProducts() {

        // Arrange

        List<Products> productsList = new ArrayList<>();

        productsList.add(new Products(/* Create a sample product here */));

        when(productService.getAllProducts()).thenReturn(productsList);

 

        // Act

        ResponseEntity<List<Products>> response = productsController.getAllProducts();

 

        // Assert

        assertEquals(HttpStatus.OK, response.getStatusCode());

        assertEquals(productsList, response.getBody());

    }

 

    @Test

    void testCreateProducts() {

        // Arrange

        Products productToCreate = new Products();

 

        // Act

        ResponseEntity<Void> response = productsController.createProducts(productToCreate);

 

        // Assert

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

    }
    @Test
    public void testUpdateProducts() throws NotFoundException, InvalidDataException {
        // Create a sample Products object to be used in the request body
        Products sampleProducts = new Products();
        // Set properties on sampleProducts as needed

        // Define the behavior of the productService mock
        Mockito.when(productService.updateProducts(Mockito.any(Products.class)))
               .thenReturn(sampleProducts);

        // Call the updateProducts method
        ResponseEntity<String> response = productsController.updateProducts(sampleProducts);

        // Assert that the method returned HttpStatus.OK
        assertEquals(HttpStatus.OK, response.getStatusCode());

        // Assert the response message
        assertEquals("Record updated successfully", response.getBody());

        // Verify that the updateProducts method was called with the provided sampleProducts
        Mockito.verify(productService).updateProducts(sampleProducts);
    }
 

    
 

    @Test
    public void testDeleteProducts() throws NotFoundException {
        int productId = 1; // Replace with a valid product ID

        // Define the behavior of the productService mock
        Mockito.doNothing().when(productService).deleteProducts(productId);

        // Call the deleteProducts method
        ResponseEntity<Void> response = productsController.deleteProducts(productId);

        // Assert that the method returned HttpStatus.NO_CONTENT
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());

        // Verify that the deleteProducts method was called with the correct productId
        Mockito.verify(productService).deleteProducts(productId);
    }

 

    @Test

    void testSearchProductsByCategory() throws NotFoundException {

        // Arrange

        String category = "SampleCategory";

        List<Products> productsList = new ArrayList<>();

        productsList.add(new Products(/* Create a sample product here */));

        when(productService.searchProductsByCategory(category)).thenReturn(productsList);

 

        // Act

        ResponseEntity<List<Products>> response = productsController.searchProductsByCategory(category);

 

        // Assert

        assertEquals(HttpStatus.OK, response.getStatusCode());

        assertEquals(productsList, response.getBody());

    }

}

 