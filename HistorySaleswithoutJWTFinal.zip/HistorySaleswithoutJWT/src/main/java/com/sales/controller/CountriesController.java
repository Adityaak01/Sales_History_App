package com.sales.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.sales.entities.Countries;
import com.sales.entities.Customers;
import com.sales.exception.InvalidDataException;
import com.sales.services.CountriesService;
import com.sales.services.CustomersService;
import com.sales.exception.NotFoundException;
import com.sales.repository.CountriesRepository;

//saleshistoryapp database

@Controller
@RequestMapping("/api/v1/Countries")
@Validated
public class CountriesController {

	@Autowired
	CountriesService countriesService;

	@GetMapping("/all")
	public ResponseEntity<List<Countries>> getAllCountries(){
		return new ResponseEntity<List<Countries>>(countriesService.getAllCountries(), HttpStatus.OK);
	}

	@PostMapping("/create")
	public ResponseEntity<Void> createCountries(@Valid @RequestBody Countries countries){
		countriesService.createCountries(countries);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PutMapping("/edit")
	public ResponseEntity<String> updateCountries(@Valid @RequestBody Countries countries) throws NotFoundException{

		Countries c = countriesService.updateCountries(countries);
		if (c == null) {
			throw new InvalidDataException("Record update failed");
		}
		return new ResponseEntity<String>("Record updated successfully", HttpStatus.OK);

	}

	@DeleteMapping("/delete/{countryId}")
	public ResponseEntity<Void> deleteCountries(@PathVariable int countryId) throws NotFoundException{
		countriesService.deleteCountries(countryId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
	}
	

	@GetMapping("/count")
	public ResponseEntity<List<Map<String, Object>>> getCustomerCountByCountry() {
		List<Map<String, Object>> list = countriesService.getCustomerCountByCountry();
		if (list.size() == 0) {
			throw new NotFoundException("No customers data found in the countries");
		}
		return new ResponseEntity<List<Map<String, Object>>>(list, HttpStatus.OK);
	}

	@GetMapping("/customers/countryRegion/{countryRegion}")
	public ResponseEntity<List<Object[]>> getCustomerCountByRegion(@PathVariable("countryRegion") String countryRegion) {
		List<Object[]> list = countriesService.getCustomerCountByRegion(countryRegion);
		if (list.size() == 0) {
			throw new NotFoundException("No customers data found in the region "+countryRegion);
		}
		return new ResponseEntity<List<Object[]>>(list, HttpStatus.OK);
	}


}
