package com.sales.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Channels;
import com.sales.exception.NotFoundException;
import com.sales.repository.ChannelsRepository; 

@Service
public class ChannelsServiceImpl implements ChannelsService {	
	@Autowired
	ChannelsRepository channelsRepository;



	public ChannelsServiceImpl(ChannelsRepository channelsRepository2) {
		// TODO Auto-generated constructor stub
	}



	@Override

	public Channels getChannelsById(int channelId) throws NotFoundException{

		if(channelsRepository.findById(channelId).isEmpty())

			throw new NotFoundException("The Channels with"+channelId+"does not exists");



		return channelsRepository.findById(channelId).get();

	}
	



	@Override

	public List<Channels> getAllChannels() {



		return channelsRepository.findAll();

	}
	

	@Override

	public void createChannels(Channels channels) {

		// TODO Auto-generated method stub

		channelsRepository.save(channels);

	}
	



	@Override

	public Channels updateChannels(Channels channels)throws NotFoundException {

		if(channelsRepository.findById(channels.getChannelId()).isEmpty())

			throw new NotFoundException("The Channel with"+channels.getChannelId()+"does not exists");



		return channelsRepository.save(channels);

	}
	



	@Override

	public void deleteChannels(int channelId) throws NotFoundException{

		if(channelsRepository.findById(channelId).isEmpty())

			throw new NotFoundException("The Channels with"+channelId+"does not exists");
		channelsRepository.deleteById(channelId);


	}
	

	@Override
	public Channels saveChannels(Channels channels) {
		// TODO Auto-generated method stub
		return null;
	}



}