package com.sales.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.sales.entities.Products;
import com.sales.exception.NotFoundException;
import com.sales.repository.ProductsRepository;



@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductsRepository productsRepository;

	@Override
	public Products getProductById(int productId) throws NotFoundException{
		if(productsRepository.findById(productId).isEmpty())
			throw new NotFoundException("The Product with "+productId+" does not exists");

		return productsRepository.findById(productId).get();
	}
	

	@Override
	public List<Products> getAllProducts() {

		return productsRepository.findAll();
	}
	

	@Override
	public void createProducts(Products products) {
		// TODO Auto-generated method stub
		productsRepository.save(products);
	}

	@Override
	public Products updateProducts(Products products)throws NotFoundException {
		if(productsRepository.findById(products.getProductId()).isEmpty())
			throw new NotFoundException("The Product with "+products.getProductId()+" does not exists");

		return productsRepository.save(products);
	}
	

	@Override
	public void deleteProducts(int productId) throws NotFoundException{
		if(productsRepository.findById(productId).isEmpty())
			throw new NotFoundException("The Product with "+productId+" does not exists"); 
		productsRepository.deleteById(productId);

	}
	


	@Override
	public List<Products> searchProductsByCategory(String productCategory) throws NotFoundException {
		if(productsRepository.findProductsByCategory(productCategory).isEmpty())

			throw new NotFoundException("The Customers with "+productCategory+" does not exists");

		return productsRepository.findProductsByCategory(productCategory);
	}

	@Override
	public List<Products> searchProductsByStatus(String productStatus) throws NotFoundException {
		if(productsRepository.findProductsByStatus(productStatus).isEmpty())

			throw new NotFoundException("The Customers with "+productStatus+" does not exists");

		return productsRepository.findProductsByStatus(productStatus);
	}

	@Override
	public List<Products> searchProductsBySubCategory(String productSubCategory) throws NotFoundException {
		if(productsRepository.findProductsBySubCategory(productSubCategory).isEmpty())

			throw new NotFoundException("The Customers with "+productSubCategory+" does not exists");

		return productsRepository.findProductsBySubCategory(productSubCategory);
	}



	@Override
	public List<Products> searchProductsBySupplierId(int productSupplierId) throws NotFoundException {
		if(productsRepository.findProductsBySupplierId(productSupplierId).isEmpty())

			throw new NotFoundException("The Customers with "+productSupplierId+" does not exists");

		return productsRepository.findProductsBySupplierId(productSupplierId);
	}

	@Override
	public List<Products> searchDuplicateProductsByProductName() {
		return productsRepository.findDuplicateProductsByProductName();
	}

	@Override
	public List<Object[]> getProductsByChannelWiseSold(String channel) {
		return productsRepository.findProductsByChannelWiseSold(channel);
	}



	@Override
	public List<Products> getProductsOrderedByField(String field) {
		return productsRepository.findAll(Sort.by(Sort.Direction.ASC, field));
	}

}
