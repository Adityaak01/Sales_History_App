package com.sales.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Customers;
import com.sales.repository.CustomersRepository;
import com.sales.exception.NotFoundException;

@Service
public class CustomersServiceImpl implements CustomersService {	
	@Autowired
	CustomersRepository customersRepository;



	@Override

	public Customers getCustomersById(int customerId) throws NotFoundException{

		if(customersRepository.findById(customerId).isEmpty())

			throw new NotFoundException("The Customers with"+customerId+"does not exists");



		return customersRepository.findById(customerId).get();

	}



	@Override

	public List<Customers> getAllCustomers() {



		return customersRepository.findAll();

	}




	@Override

	public void createCustomers(Customers customers) {

		// TODO Auto-generated method stub

		customersRepository.save(customers);

	}



	@Override

	public Customers updateCustomers(Customers customers)throws NotFoundException {

		if(customersRepository.findById(customers.getCustomerId()).isEmpty())

			throw new NotFoundException("The Customers with"+customers.getCustomerId()+"does not exists");



		return customersRepository.save(customers);

	}
	

	@Override

	public void deleteCustomers(int customerId) throws NotFoundException{

		if(customersRepository.findById(customerId).isEmpty()) 

			throw new NotFoundException("The Customers with"+customerId+"does not exists");
		customersRepository.deleteById(customerId);

	}
	

	@Override
	public List<Customers> searchCustomersByFirstName(String CustomerFirstName) throws NotFoundException {

		return customersRepository.findCustomersByFirstName(CustomerFirstName);

	}



	@Override
	public List<Customers> searchCustomersByCity(String customerCity) throws NotFoundException {

		return customersRepository.findCustomersByCity(customerCity);

	}



	@Override
	public List<Customers> searchCustomersByIncome(String customerIncomeLevel) throws NotFoundException {
		return customersRepository.findCustomersByIncome(customerIncomeLevel);

	}

	@Override
	public List<Customers> searchCustomersBetweenCreditLimit(int minCreditLimit, int maxCreditLimit) throws NotFoundException{

		return customersRepository.findCustomersByCreditLimitBetween(minCreditLimit, maxCreditLimit);


	}






	@Override

	public Customers updateCustomerCreditLimit(int customerId, int newCreditLimit) throws NotFoundException {

		if (customersRepository.findById(customerId).isEmpty())



			throw new NotFoundException("the employee with does not exists");



		Customers customers = customersRepository.findById(customerId).get();



		customers.setCustomerCreditLimit(newCreditLimit);



		return customersRepository.save(customers);

	}



}