package com.sales.services;

import java.util.*;

import org.springframework.stereotype.Service;

import com.sales.entities.Countries;

import com.sales.exception.NotFoundException;



public interface CountriesService {

	Countries getCountriesById(int countryId) throws NotFoundException;

	List<Countries> getAllCountries();

	void createCountries(Countries countries);

	Countries updateCountries(Countries countries) throws NotFoundException;

	void deleteCountries(int countryId) throws NotFoundException;

	List<Map<String, Object>> getCustomerCountByCountry();
	List<Object[]> getCustomerCountByRegion(String countryRegion);





}