package com.sales.exception;

public class InvalidDataException extends RuntimeException{
    public InvalidDataException(String meassage){
        super(meassage);
    }
}
