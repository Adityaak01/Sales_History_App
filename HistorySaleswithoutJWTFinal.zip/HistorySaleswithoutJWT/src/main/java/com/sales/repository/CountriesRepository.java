package com.sales.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sales.entities.Countries;

public interface CountriesRepository extends JpaRepository<Countries, Integer>{


	@Query("select c.countries.countryName AS countries, count(c) as customerCount from Customers c group by c.countries.countryName")
	List<Map<String, Object>> getCustomerCountCountryWise();


	@Query("SELECT c.countries.countryRegion AS countries, COUNT(c) AS customerCount FROM Customers c WHERE c.countries.countryRegion = :countryRegion GROUP BY c.countries.countryRegion")
	List<Object[]> getCustomerCountRegionWise(@Param("countryRegion") String countryRegion);


}
