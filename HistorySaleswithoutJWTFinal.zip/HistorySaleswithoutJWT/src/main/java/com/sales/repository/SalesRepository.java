package com.sales.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sales.entities.Sales;



public interface SalesRepository extends JpaRepository<Sales, Integer>{

	@Query("SELECT m FROM Sales m WHERE MONTH(m.times.timeId) = :givenMonth")
	List<Sales> findAllSalesByQuarter(@Param("givenMonth") int month);

	@Query("SELECT s FROM Sales s WHERE s.times.timeId = :date")
	List<Sales> findByDate(@Param("date") Date date);

	@Query("SELECT p.productCategory, SUM(s.salesQuantitySold) " + "FROM Sales s JOIN s.products p "
			+ "GROUP BY p.productCategory")
	List<Object[]> findSalesQuantitySoldByCategory();

	@Query("SELECT p.productCategory, SUM(s.salesQuantitySold) FROM Sales s JOIN s.products p "
			+ "WHERE YEAR(s.times.timeId) = :year GROUP BY p.productCategory")
	List<Object[]> findSalesQuantitySoldByCategoryYearWise(@Param("year") int year);

	@Query("SELECT p.productCategory, sum(s.salesAmountSold) FROM Sales s JOIN s.products p GROUP BY p.productCategory")
	List<Object[]> findAmountSoldForSalesByCategories();

	@Query("SELECT p.productCategory, SUM(s.salesAmountSold) FROM Sales s JOIN s.products p WHERE YEAR(s.times.timeId) = :year "
			+ "GROUP BY YEAR(s.times.timeId), p.productCategory ORDER BY YEAR(s.times.timeId)")
	List<Object[]> findAmountSoldForSalesByCategoriesYearWise(@Param("year") int year);

}