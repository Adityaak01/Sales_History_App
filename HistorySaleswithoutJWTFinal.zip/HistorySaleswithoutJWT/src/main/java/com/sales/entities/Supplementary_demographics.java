package com.sales.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SUPPLEMENTARY_DEMOGRAPHICS")
public class Supplementary_demographics {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CUST_ID")
    private int custId;

 

    @Column(name = "EDUCATION", length = 21)
    private String education;

 

    @Column(name = "OCCUPATION", length = 21)
    private String occupation;

 

    @Column(name = "HOUSEHOLD_SIZE", length = 21)
    private String householdSize;

 

    @Column(name = "YRS_RESIDENCE")
    private int yearsResidence;

 

    @Column(name = "AFFINITY_CARD")
    private int affinityCard;

 

    @Column(name = "BULK_PACK_DISKETTES")
    private int bulkPackDiskettes;

 

    @Column(name = "FLAT_PANEL_MONITOR")
    private int flatPanelMonitor;

 

    @Column(name = "HOME_THEATER_PACKAGE")
    private int homeTheaterPackage;

 

    @Column(name = "BOOKKEEPING_APPLICATION")
    private int bookkeepingApplication;

 

    @Column(name = "PRINTER_SUPPLIES")
    private int printerSupplies;

 

    @Column(name = "Y_BOX_GAMES")
    private int yBoxGames;

 

    @Column(name = "OS_DOC_SET_KANJI")
    private int osDocSetKanji;

 

    @Column(name = "COMMENTS", length = 4000)
    private String comments;



	public Supplementary_demographics(int custId, String education, String occupation, String householdSize,
			int yearsResidence, int affinityCard, int bulkPackDiskettes, int flatPanelMonitor, int homeTheaterPackage,
			int bookkeepingApplication, int printerSupplies, int yBoxGames, int osDocSetKanji, String comments) {
		super();
		this.custId = custId;
		this.education = education;
		this.occupation = occupation;
		this.householdSize = householdSize;
		this.yearsResidence = yearsResidence;
		this.affinityCard = affinityCard;
		this.bulkPackDiskettes = bulkPackDiskettes;
		this.flatPanelMonitor = flatPanelMonitor;
		this.homeTheaterPackage = homeTheaterPackage;
		this.bookkeepingApplication = bookkeepingApplication;
		this.printerSupplies = printerSupplies;
		this.yBoxGames = yBoxGames;
		this.osDocSetKanji = osDocSetKanji;
		this.comments = comments;
	}
	



	public Supplementary_demographics() {
		super();
	}




	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getEducation() {
		return education;
	}



	public void setEducation(String education) {
		this.education = education;
	}



	public String getOccupation() {
		return occupation;
	}



	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}



	public String getHouseholdSize() {
		return householdSize;
	}



	public void setHouseholdSize(String householdSize) {
		this.householdSize = householdSize;
	}



	public int getYearsResidence() {
		return yearsResidence;
	}



	public void setYearsResidence(int yearsResidence) {
		this.yearsResidence = yearsResidence;
	}



	public int getAffinityCard() {
		return affinityCard;
	}



	public void setAffinityCard(int affinityCard) {
		this.affinityCard = affinityCard;
	}



	public int getBulkPackDiskettes() {
		return bulkPackDiskettes;
	}



	public void setBulkPackDiskettes(int bulkPackDiskettes) {
		this.bulkPackDiskettes = bulkPackDiskettes;
	}



	public int getFlatPanelMonitor() {
		return flatPanelMonitor;
	}



	public void setFlatPanelMonitor(int flatPanelMonitor) {
		this.flatPanelMonitor = flatPanelMonitor;
	}



	public int getHomeTheaterPackage() {
		return homeTheaterPackage;
	}



	public void setHomeTheaterPackage(int homeTheaterPackage) {
		this.homeTheaterPackage = homeTheaterPackage;
	}



	public int getBookkeepingApplication() {
		return bookkeepingApplication;
	}



	public void setBookkeepingApplication(int bookkeepingApplication) {
		this.bookkeepingApplication = bookkeepingApplication;
	}



	public int getPrinterSupplies() {
		return printerSupplies;
	}



	public void setPrinterSupplies(int printerSupplies) {
		this.printerSupplies = printerSupplies;
	}



	public int getyBoxGames() {
		return yBoxGames;
	}



	public void setyBoxGames(int yBoxGames) {
		this.yBoxGames = yBoxGames;
	}



	public int getOsDocSetKanji() {
		return osDocSetKanji;
	}



	public void setOsDocSetKanji(int osDocSetKanji) {
		this.osDocSetKanji = osDocSetKanji;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}




	@Override
	public String toString() {
		return "Supplementary_demographics [custId=" + custId + ", education=" + education + ", occupation="
				+ occupation + ", householdSize=" + householdSize + ", yearsResidence=" + yearsResidence
				+ ", affinityCard=" + affinityCard + ", bulkPackDiskettes=" + bulkPackDiskettes + ", flatPanelMonitor="
				+ flatPanelMonitor + ", homeTheaterPackage=" + homeTheaterPackage + ", bookkeepingApplication="
				+ bookkeepingApplication + ", printerSupplies=" + printerSupplies + ", yBoxGames=" + yBoxGames
				+ ", osDocSetKanji=" + osDocSetKanji + ", comments=" + comments + "]";
	}
    
    

 
}