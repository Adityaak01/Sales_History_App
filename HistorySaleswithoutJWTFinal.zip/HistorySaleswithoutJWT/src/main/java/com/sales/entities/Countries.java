package com.sales.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "COUNTRIES")
public class Countries {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "COUNTRY_ID")
    private int countryId;

 
    @NotNull(message = "Country ISO code is required")
    @Size(min = 2, max = 2, message = "Country ISO code must be exactly 2 characters")
    @Column(name = "COUNTRY_ISO_CODE", length = 2)
    private String countryISOCode;

 

    @Size(max = 40, message = "Country name must be at most 40 characters")
    @Column(name = "COUNTRY_NAME", length = 40)
    private String countryName;

 
    @Size(max = 30, message = "Country subregion must be at most 30 characters")
    @Column(name = "COUNTRY_SUBREGION", length = 30)
    private String countrySubRegion;

 

    @Column(name = "COUNTRY_SUBREGION_ID")
    private int countrySubRegionId;

 
    @Size(max = 40, message = "Country region must be at most 40 characters")
    @Column(name = "COUNTRY_REGION", length = 40)
    private String countryRegion;

 

    @Column(name = "COUNTRY_REGION_ID")
    private int countryRegionId;

 
    @Size(max = 11, message = "Country total must be at most 11 characters")
    @Column(name = "COUNTRY_TOTAL", length = 11)
    private String countryTotal;

 

    @Column(name = "COUNTRY_TOTAL_ID")
    private int countryTotalId;

    @JsonIgnore
    @OneToMany(mappedBy = "countries", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Customers> customers;

    
    

	public Countries(int countryId, String countryIsoCode, String countryName, String countrySubregion,
			int countrySubregionId, String countryRegion, int countryRegionId, String countryTotal, int countryTotalId,
			List<Customers> customers) {
		super();
		this.countryId = countryId;
		this.countryISOCode = countryIsoCode;
		this.countryName = countryName;
		this.countrySubRegion = countrySubregion;
		this.countrySubRegionId = countrySubregionId;
		this.countryRegion = countryRegion;
		this.countryRegionId = countryRegionId;
		this.countryTotal = countryTotal;
		this.countryTotalId = countryTotalId;
		this.customers = customers;
	}

	


	public Countries() {
		super();
	}




	public int getCountryId() {
		return countryId;
	}



	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}



	public String getCountryIsoCode() {
		return countryISOCode;
	}



	public void setCountryIsoCode(String countryIsoCode) {
		this.countryISOCode = countryIsoCode;
	}



	public String getCountryName() {
		return countryName;
	}



	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}



	public String getCountrySubregion() {
		return countrySubRegion;
	}



	public void setCountrySubregion(String countrySubregion) {
		this.countrySubRegion = countrySubregion;
	}



	public int getCountrySubregionId() {
		return countrySubRegionId;
	}



	public void setCountrySubregionId(int countrySubregionId) {
		this.countrySubRegionId = countrySubregionId;
	}



	public String getCountryRegion() {
		return countryRegion;
	}



	public void setCountryRegion(String countryRegion) {
		this.countryRegion = countryRegion;
	}



	public int getCountryRegionId() {
		return countryRegionId;
	}



	public void setCountryRegionId(int countryRegionId) {
		this.countryRegionId = countryRegionId;
	}



	public String getCountryTotal() {
		return countryTotal;
	}



	public void setCountryTotal(String countryTotal) {
		this.countryTotal = countryTotal;
	}



	public int getCountryTotalId() {
		return countryTotalId;
	}



	public void setCountryTotalId(int countryTotalId) {
		this.countryTotalId = countryTotalId;
	}



	public List<Customers> getCustomers() {
		return customers;
	}



	public void setCustomers(List<Customers> customers) {
		this.customers = customers;
	}




	@Override
	public String toString() {
		return "Countries [countryId=" + countryId + ", countryIsoCode=" + countryISOCode + ", countryName="
				+ countryName + ", countrySubregion=" + countrySubRegion + ", countrySubregionId=" + countrySubRegionId
				+ ", countryRegion=" + countryRegion + ", countryRegionId=" + countryRegionId + ", countryTotal="
				+ countryTotal + ", countryTotalId=" + countryTotalId + ", customers=" + customers + "]";
	}
	
	
	
	
	
	
    
}
