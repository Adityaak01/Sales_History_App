package com.sales.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "CHANNELS")
public class Channels {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CHANNEL_ID")
    private int channelId;

 
	@Size(max = 20, message = "Channel description must be at most 20 characters")
    @Column(name = "CHANNEL_DESC", length = 20)
    private String channelDescription;

 
	@Size(max = 20, message = "Channel class must be at most 20 characters")
    @Column(name = "CHANNEL_CLASS", length = 20)
    private String channelClass;

 

    @Column(name = "CHANNEL_CLASS_ID")
    private int channelClassId;

 
    @Size(max = 13, message = "Channel total must be at most 13 characters")
    @Column(name = "CHANNEL_TOTAL", length = 13)
    private String channelTotal;

 

    @Column(name = "CHANNEL_TOTAL_ID")
    private int channelTotalId;


    @OneToMany(mappedBy = "channels", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Sales> sales;

	@OneToMany(mappedBy = "channels", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Cost> costs;

	


	public Channels(int channelId, String channelDescription, String channelClass, int channelClassId,
			String channelTotal, int channelTotalId, List<Sales> sales, List<Cost> costs) {
		super();
		this.channelId = channelId;
		this.channelDescription = channelDescription;
		this.channelClass = channelClass;
		this.channelClassId = channelClassId;
		this.channelTotal = channelTotal;
		this.channelTotalId = channelTotalId;
		this.sales = sales;
		this.costs = costs;
	}

	public Channels() {
		super();
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

	public String getChannelDescription() {
		return channelDescription;
	}

	public void setChannelDescription(String channelDescription) {
		this.channelDescription = channelDescription;
	}

	public String getChannelClass() {
		return channelClass;
	}

	public void setChannelClass(String channelClass) {
		this.channelClass = channelClass;
	}

	public int getChannelClassId() {
		return channelClassId;
	}

	public void setChannelClassId(int channelClassId) {
		this.channelClassId = channelClassId;
	}

	public String getChannelTotal() {
		return channelTotal;
	}

	public void setChannelTotal(String channelTotal) {
		this.channelTotal = channelTotal;
	}

	public int getChannelTotalId() {
		return channelTotalId;
	}

	public void setChannelTotalId(int channelTotalId) {
		this.channelTotalId = channelTotalId;
	}

	public List<Sales> getSales() {
		return sales;
	}

	public void setSales(List<Sales> sales) {
		this.sales = sales;
	}

	public List<Cost> getCosts() {
		return costs;
	}

	public void setCosts(List<Cost> costs) {
		this.costs = costs;
	}

	@Override
	public String toString() {
		return "Channels [channelId=" + channelId + ", channelDescription=" + channelDescription + ", channelClass="
				+ channelClass + ", channelClassId=" + channelClassId + ", channelTotal=" + channelTotal
				+ ", channelTotalId=" + channelTotalId + ", sales=" + sales + ", costs=" + costs + "]";
	}
	

}
