package com.sales.dto;

public class ApiResponse {

}
