package com.sales.services;

import java.util.*;

import org.springframework.stereotype.Service;

import com.sales.entities.Countries;
import com.sales.exception.CountriesNotFoundException;


@Service
public interface CountriesService {
	
	Countries getCountriesById(int CountriesId) throws CountriesNotFoundException;

	List<Countries> getAllCountries();

	void createCountries(Countries Countries);

	Countries updateCountries(Countries Countries) throws CountriesNotFoundException;

	void deleteCountries(int CountriesId) throws CountriesNotFoundException;

 

}