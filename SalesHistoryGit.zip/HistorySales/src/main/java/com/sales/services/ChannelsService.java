package com.sales.services;

import java.util.*;

import com.sales.entities.Channels;
import com.sales.exception.ChannelsNotFoundException;


public interface ChannelsService {
	
	Channels getChannelsById(int ChannelsId) throws ChannelsNotFoundException;

	List<Channels> getAllChannels();

	void createChannels(Channels Channels);

	Channels updateChannels(Channels Channels) throws ChannelsNotFoundException;

	void deleteChannels(int ChannelsId) throws ChannelsNotFoundException;

 

}
