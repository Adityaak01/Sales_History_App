package com.sales.services;

import java.util.*;

import com.sales.exception.CostsNotFoundException;

import com.sales.entities.Cost;

 

public interface CostsService {

 

	Cost getCostById(int costsId) throws CostsNotFoundException;

 

	List<Cost> getAllCosts();

 

	void createCosts(Cost costs);

 

	Cost updateCosts(Cost costs) throws CostsNotFoundException;

 

	void deleteCosts(int costsId) throws CostsNotFoundException;

 

}