package com.sales.services;

import java.util.*;

import org.springframework.stereotype.Service;

import com.sales.entities.Customers;
import com.sales.exception.CustomersNotFoundException;


public interface CustomersService {
	
	Customers getCustomersById(int CustomersId) throws CustomersNotFoundException;

	List<Customers> getAllCustomers();

	void createCustomers(Customers Customers);

	Customers updateCustomers(Customers Customers) throws CustomersNotFoundException;

	void deleteCustomers(int CustomersId) throws CustomersNotFoundException;

 

}
