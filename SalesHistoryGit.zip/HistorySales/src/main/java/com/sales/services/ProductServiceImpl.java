package com.sales.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.exception.ProductNotFoundException;
import com.sales.entities.Products;
import com.sales.repository.ProductsRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductsRepository productsRepository;
	
	@Override
	public Products getProductById(int productId) throws ProductNotFoundException{
		if(productsRepository.findById(productId).isEmpty())
			throw new ProductNotFoundException("The Product with"+productId+"does not exists");
		
		return productsRepository.findById(productId).get();
	}

	@Override
	public List<Products> getAllProducts() {
		
		return productsRepository.findAll();
	}

	@Override
	public void createProducts(Products products) {
		// TODO Auto-generated method stub
		productsRepository.save(products);
	}

	@Override
	public Products updateProducts(Products products)throws ProductNotFoundException {
		if(productsRepository.findById(products.getProductId()).isEmpty())
			throw new ProductNotFoundException("The Product with"+products.getProductId()+"does not exists");
		
		return productsRepository.save(products);
	}

	@Override
	public void deleteProducts(int productsId) throws ProductNotFoundException{
		if(productsRepository.findById(productsId).isEmpty())
			throw new ProductNotFoundException("The Product with"+productsId+"does not exists"); 
		
	}

}
