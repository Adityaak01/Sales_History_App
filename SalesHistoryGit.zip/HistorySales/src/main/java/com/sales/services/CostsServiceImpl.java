package com.sales.services;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sales.exception.CostsNotFoundException;

import com.sales.entities.*;

import com.sales.repository.CostRepository;

 

 

public class CostsServiceImpl implements CostsService {

 

	

 

	@Autowired

	CostRepository costsRepository;

 

	

 

	@Override

	public Cost getCostById(int costsId) throws CostsNotFoundException{

 

		if(costsRepository.findById(costsId).isEmpty())

 

			throw new CostsNotFoundException("The Product with"+costsId+"does not exists");

 

		

 

		return costsRepository.findById(costsId).get();

 

	}

 

 

	@Override

	public List<Cost> getAllCosts() {

 

		

 

		return costsRepository.findAll();

 

	}

 

 

	@Override

	public void createCosts(Cost costs) {

		// TODO Auto-generated method stub

 

		costsRepository.save(costs);

 

	}

 

 

	@Override

	public Cost updateCosts(Cost costs)throws CostsNotFoundException {

 

		if(costsRepository.findById(costs.getCostId()).isEmpty())

 

			throw new CostsNotFoundException("The costs with"+costs.getCostId()+"does not exists");

 

		

 

		return costsRepository.save(costs);

 

	}

 

 

	@Override

	public void deleteCosts(int costsId) throws CostsNotFoundException{

 

		if(costsRepository.findById(costsId).isEmpty())

 

			throw new CostsNotFoundException("The Product with"+costsId+"does not exists");

 

		

 

	}

 

 

}