package com.sales.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Countries;
import com.sales.exception.CountriesNotFoundException;

import com.sales.repository.CountriesRepository; 


@Service
public class CountriesServiceImpl implements CountriesService {	
	@Autowired
	CountriesRepository countriesRepository;

	

	@Override

	public Countries getCountriesById(int countryId) throws CountriesNotFoundException{

		if(countriesRepository.findById(countryId).isEmpty())

			throw new CountriesNotFoundException("The Countries with"+countryId+"does not exists");

		

		return countriesRepository.findById(countryId).get();

	}

 

	@Override

	public List<Countries> getAllCountries() {

		

		return countriesRepository.findAll();

	}

 

	@Override

	public void createCountries(Countries countries) {

		// TODO Auto-generated method stub

		countriesRepository.save(countries);

	}

 

	@Override

	public Countries updateCountries(Countries countries)throws CountriesNotFoundException {

		if(countriesRepository.findById(countries.getCountryId()).isEmpty())

			throw new CountriesNotFoundException("The Channel with"+countries.getCountryId()+"does not exists");

		

		return countriesRepository.save(countries);

	}

 

	@Override

	public void deleteCountries(int countryId) throws CountriesNotFoundException{

		if(countriesRepository.findById(countryId).isEmpty())

			throw new CountriesNotFoundException("The Countries with"+countryId+"does not exists");

		countriesRepository.deleteById(countryId);

	}

 

}