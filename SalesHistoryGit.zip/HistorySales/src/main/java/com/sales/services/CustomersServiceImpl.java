package com.sales.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Customers;
import com.sales.exception.CustomersNotFoundException;

import com.sales.repository.CustomersRepository;

@Service
public class CustomersServiceImpl implements CustomersService {	
	@Autowired
	CustomersRepository customersRepository;

	

	@Override

	public Customers getCustomersById(int customerId) throws CustomersNotFoundException{

		if(customersRepository.findById(customerId).isEmpty())

			throw new CustomersNotFoundException("The Customers with"+customerId+"does not exists");

		

		return customersRepository.findById(customerId).get();

	}

 

	@Override

	public List<Customers> getAllCustomers() {

		

		return customersRepository.findAll();

	}

 

	@Override

	public void createCustomers(Customers customers) {

		// TODO Auto-generated method stub

		customersRepository.save(customers);

	}

 

	@Override

	public Customers updateCustomers(Customers customers)throws CustomersNotFoundException {

		if(customersRepository.findById(customers.getCustomerId()).isEmpty())

			throw new CustomersNotFoundException("The Customers with"+customers.getCustomerId()+"does not exists");

		

		return customersRepository.save(customers);

	}

 

	@Override

	public void deleteCustomers(int customersId) throws CustomersNotFoundException{

		if(customersRepository.findById(customersId).isEmpty())

			throw new CustomersNotFoundException("The Customers with"+customersId+"does not exists");

		

	}

 

}