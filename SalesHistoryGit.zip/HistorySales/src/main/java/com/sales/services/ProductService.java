package com.sales.services;
import java.util.*;

import org.springframework.stereotype.Service;

import com.sales.exception.ProductNotFoundException;
import com.sales.entities.Products;

@Service
public interface ProductService {
	Products getProductById(int productsId) throws ProductNotFoundException;
	List<Products> getAllProducts();
	void createProducts(Products products);
	Products updateProducts(Products products) throws ProductNotFoundException;
	void deleteProducts(int productsId) throws ProductNotFoundException;

}
