package com.sales.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sales.entities.Countries;
import com.sales.entities.Customers;
import com.sales.exception.CountriesNotFoundException;
import com.sales.services.CountriesService;
import com.sales.services.CustomersService;


@Controller
@RequestMapping("/api/v1/Countries")
public class CountriesController {

	@Autowired
	CountriesService countriesService;
	
	@GetMapping("/")
	public ResponseEntity<List<Countries>> getAllCountries(){
		return new ResponseEntity<List<Countries>>(countriesService.getAllCountries(), HttpStatus.OK);
	}
	
	@PostMapping("/")
	public ResponseEntity<Void> createCountries(@RequestBody Countries countries){
		countriesService.createCountries(countries);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	@PutMapping("/edit/{countryId}")
	public ResponseEntity<String> updateCountry(@PathVariable int countryId, @RequestBody Countries updatedCountry) {
	    try {
	        Countries existingCountry = countriesService.updateCountries(updatedCountry);
	        if (existingCountry == null) {
	            // If the country does not exist, return a 404 Not Found response
	            return new ResponseEntity<>("Country not found", HttpStatus.NOT_FOUND);
	        }
	        
	        // Return a success message
	        return new ResponseEntity<>("Record Updated Successfully", HttpStatus.OK);
	    } catch (CountriesNotFoundException e) {
	        // Handle the exception if the country is not found
	        return new ResponseEntity<>("Country not found", HttpStatus.NOT_FOUND);
	    } catch (Exception e) {
	        // Handle any other exceptions that may occur during the update process
	        return new ResponseEntity<>("Error updating country", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

	
	
	@DeleteMapping("/del/{countryId}")
    public ResponseEntity<Void> deleteCountries(@PathVariable("countryId") int countryId) throws CountriesNotFoundException {

			countriesService.deleteCountries(countryId);
        return new ResponseEntity<>(HttpStatus.OK);

    }
	

}
