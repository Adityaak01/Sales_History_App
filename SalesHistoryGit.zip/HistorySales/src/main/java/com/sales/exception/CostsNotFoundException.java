package com.sales.exception;

 

public class CostsNotFoundException extends Exception {

 

	String message;

 

	public CostsNotFoundException(String message) {

 

		this.message=message;

 

	}

 

	public String getMessage() {

 

		return this.message;

 

	}

 

}