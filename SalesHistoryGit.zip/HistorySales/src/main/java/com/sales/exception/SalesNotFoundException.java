package com.sales.exception;

public class SalesNotFoundException extends Exception {

	String message;

	public SalesNotFoundException(String message) {

		this.message=message;

	}

	public String getMessage() {

		return this.message;

	}

}

