package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entities.Cost;

public interface CostRepository extends JpaRepository<Cost, Integer>{
	
}
