package com.sales;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.sales.repository.ChannelsRepository;
import com.sales.repository.CostRepository;
import com.sales.repository.CountriesRepository;
import com.sales.repository.ProductsRepository;
import com.sales.repository.PromotionsRepository;
import com.sales.repository.SalesRepository;
import com.sales.repository.Supplementary_demographicsRepository;
import com.sales.repository.TimesRepository;


@SpringBootApplication

public class SalesHistoryApplication {
	
	@Autowired
	ProductsRepository prepo;

	@Autowired
	SalesRepository srepo;

	@Autowired
	CostRepository crepo;

	@Autowired
	TimesRepository trepo;

	@Autowired
	ProductsRepository pr1repo;

	@Autowired
	Supplementary_demographicsRepository sdrepo;

	@Autowired
	ChannelsRepository chrepo;

	@Autowired
	PromotionsRepository promorepo;

	@Autowired
	CountriesRepository counrepo;
	
	
	public static void main(String[] args) {
		SpringApplication.run(SalesHistoryApplication.class, args);
	}

}
