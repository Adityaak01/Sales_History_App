package com.sales.exception;

public class CountriesNotFoundException extends Exception {

	String message;

	public CountriesNotFoundException(String message) {

		this.message=message;

	}

	public String getMessage() {

		return this.message;

	}

}
