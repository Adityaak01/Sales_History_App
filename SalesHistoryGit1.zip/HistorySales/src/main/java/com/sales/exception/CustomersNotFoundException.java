package com.sales.exception;

public class CustomersNotFoundException extends Exception {

	String message;

	public CustomersNotFoundException(String message) {

		this.message=message;

	}

	public String getMessage() {

		return this.message;

	}

}

