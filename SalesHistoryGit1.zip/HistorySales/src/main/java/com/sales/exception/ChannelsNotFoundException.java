package com.sales.exception;

public class ChannelsNotFoundException extends Exception {

	String message;

	public ChannelsNotFoundException(String message) {

		this.message=message;

	}

	public String getMessage() {

		return this.message;

	}

}

