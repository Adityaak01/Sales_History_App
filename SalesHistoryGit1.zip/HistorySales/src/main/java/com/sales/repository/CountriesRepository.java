package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entities.Countries;

public interface CountriesRepository extends JpaRepository<Countries, Integer>{
	
}
