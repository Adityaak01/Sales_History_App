package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entities.Channels;

public interface ChannelsRepository extends JpaRepository<Channels, Integer>{
	
}
