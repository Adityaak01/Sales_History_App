package com.sales.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sales.entities.Countries;
import com.sales.entities.Customers;
import com.sales.exception.CountriesNotFoundException;
import com.sales.exception.CustomersNotFoundException;
import com.sales.services.CustomersService;


@Controller
@RequestMapping("/api/v1/Customers")
public class CustomersController {
	@Autowired
	CustomersService customersService;
	
	@GetMapping("/")
	public ResponseEntity<List<Customers>> getAllCustomers(){
		return new ResponseEntity<List<Customers>>(customersService.getAllCustomers(), HttpStatus.OK);
	}
	@PostMapping("/")
	public ResponseEntity<Void> createCustomers(@RequestBody Customers customers){
		customersService.createCustomers(customers);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	/*
	 * @PutMapping("/edit/{customerId}") public ResponseEntity<String>
	 * updateCustomer(@PathVariable int customerId, @RequestBody Customers
	 * updatedCustomer) { try { Customers existingCustomers =
	 * customersService.updateCustomers(updatedCustomer); if (existingCustomers ==
	 * null) { // If the country does not exist, return a 404 Not Found response
	 * return new ResponseEntity<>("Country not found", HttpStatus.NOT_FOUND); }
	 * 
	 * // Return a success message return new
	 * ResponseEntity<>("Record Updated Successfully", HttpStatus.OK); } catch
	 * (CustomersNotFoundException e) { // Handle the exception if the country is
	 * not found return new ResponseEntity<>("Country not found",
	 * HttpStatus.NOT_FOUND); } catch (Exception e) { // Handle any other exceptions
	 * that may occur during the update process return new
	 * ResponseEntity<>("Error updating country", HttpStatus.INTERNAL_SERVER_ERROR);
	 * } }
	 */
	
	@PutMapping("/")
	public ResponseEntity<List<Customers>> updateCustomers(@RequestBody Customers customers) throws CustomersNotFoundException {
		customersService.updateCustomers(customers);
		return new ResponseEntity<List<Customers>>(HttpStatus.CREATED);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCustomers(@PathVariable int customersId ,@RequestBody Customers customers) throws CustomersNotFoundException{
		customersService.deleteCustomers(customersId);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

}
