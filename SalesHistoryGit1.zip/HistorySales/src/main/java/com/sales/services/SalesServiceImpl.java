package com.sales.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales.entities.Sales;
import com.sales.exception.SalesNotFoundException;

import com.sales.repository.SalesRepository; 

@Service
public class SalesServiceImpl implements SalesService {	
	@Autowired
	SalesRepository salesRepository;

	

	@Override

	public Sales getSalesById(int salesId) throws SalesNotFoundException{

		if(salesRepository.findById(salesId).isEmpty())

			throw new SalesNotFoundException("The Sales with"+salesId+"does not exists");

		

		return salesRepository.findById(salesId).get();

	}

 

	@Override

	public List<Sales> getAllSales() {

		

		return salesRepository.findAll();

	}

 

	@Override

	public void createSales(Sales sales) {

		// TODO Auto-generated method stub

		salesRepository.save(sales);

	}

 

	@Override

	public Sales updateSales(Sales sales)throws SalesNotFoundException {

		if(salesRepository.findById(sales.getSalesId()).isEmpty())

			throw new SalesNotFoundException("The Sales with"+sales.getSalesId()+"does not exists");

		

		return salesRepository.save(sales);

	}

 

	@Override

	public void deleteSales(int salesId) throws SalesNotFoundException{

		if(salesRepository.findById(salesId).isEmpty())

			throw new SalesNotFoundException("The Sales with"+salesId+"does not exists");

		

	}

 

}