package com.sales.services;

import java.util.*;

import com.sales.entities.Sales;
import com.sales.exception.SalesNotFoundException;


public interface SalesService {
	
	Sales getSalesById(int SalesId) throws SalesNotFoundException;

	List<Sales> getAllSales();

	void createSales(Sales Sales);

	Sales updateSales(Sales Sales) throws SalesNotFoundException;

	void deleteSales(int SalesId) throws SalesNotFoundException;

 

}
