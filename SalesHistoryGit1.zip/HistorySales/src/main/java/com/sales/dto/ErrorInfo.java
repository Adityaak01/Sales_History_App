package com.sales.dto;

public class ErrorInfo {

}
