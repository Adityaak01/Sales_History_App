package com.sales.entities;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

 

@Entity
@Table(name = "COSTS")
public class Cost {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "COST_ID")
	 private int costId;
	
   
    @Column(name = "unit_cost", precision = 10, scale = 2)
    private BigDecimal unitCost;

 

    @Column(name = "unit_price", precision = 10, scale = 2)
    private BigDecimal unitPrice;


    @ManyToOne(cascade = CascadeType.ALL)
    @JsonIgnore
	@JoinColumn(name = "PROMO_ID")
	private Promotions promotions;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JsonIgnore
	@JoinColumn(name = "CHANNEL_ID")
	private Channels channels; 

	@ManyToOne(cascade = CascadeType.ALL)
	@JsonIgnore
	@JoinColumn(name = "PROD_ID")
	private Products products; 

	@ManyToOne(cascade = CascadeType.ALL)
	@JsonIgnore
	@JoinColumn(name = "TIME_ID")
	private Times times; 

	
	
	public Cost(int costId, BigDecimal unitCost, BigDecimal unitPrice, Promotions promotions, Channels channels,
			Products products, Times times) {
		super();
		this.costId = costId;
		this.unitCost = unitCost;
		this.unitPrice = unitPrice;
		this.promotions = promotions;
		this.channels = channels;
		this.products = products;
		this.times = times;
	}
	
	



	public Cost() {
		super();
	}





	public int getCostId() {
		return costId;
	}



	public void setCostId(int costId) {
		this.costId = costId;
	}



	public Promotions getPromotions() {
		return promotions;
	}



	public void setPromotions(Promotions promotions) {
		this.promotions = promotions;
	}



	public Channels getChannels() {
		return channels;
	}



	public void setChannels(Channels channels) {
		this.channels = channels;
	}



	public Products getProducts() {
		return products;
	}



	public void setProducts(Products products) {
		this.products = products;
	}



	public Times getTimes() {
		return times;
	}



	public void setTimes(Times times) {
		this.times = times;
	}




	public BigDecimal getUnitCost() {
		return unitCost;
	}



	public void setUnitCost(BigDecimal unitCost) {
		this.unitCost = unitCost;
	}



	public BigDecimal getUnitPrice() {
		return unitPrice;
	}



	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}





	@Override
	public String toString() {
		return "Cost [costId=" + costId + ", unitCost=" + unitCost + ", unitPrice=" + unitPrice + ", promotions="
				+ promotions + ", channels=" + channels + ", products=" + products + ", times=" + times + "]";
	}
	
	


    
    
}
