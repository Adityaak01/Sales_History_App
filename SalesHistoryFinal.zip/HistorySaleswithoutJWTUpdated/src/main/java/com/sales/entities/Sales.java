package com.sales.entities;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMin;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SALES")
public class Sales {
  
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SALES_ID")
	private int salesId;
	
    @Column(name = "QUANTITY_SOLD")
    private int salesQuantitySold;

    @DecimalMin(value = "0.00", message = "Amount sold cannot be negative")
    @Column(name = "AMOUNT_SOLD", precision = 10, scale = 2)
    private BigDecimal salesAmountSold;
    
    @ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PROMO_ID")
    @JsonIgnore
	private Promotions promotions;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PROD_ID")
	@JsonIgnore
	private Products products; 

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CUST_ID")
	@JsonIgnore
	private Customers customers; 
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CHANNEL_ID")
	@JsonIgnore
	private Channels channels; 
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "TIME_ID")
	@JsonIgnore
	private Times times;

	
	
	public Sales() {
		super();
	}

	public int getSalesId() {
		return salesId;
	}

	public void setSalesId(int salesId) {
		this.salesId = salesId;
	}

	public int getSalesQuantitySold() {
		return salesQuantitySold;
	}

	public void setSalesQuantitySold(int salesQuantitySold) {
		this.salesQuantitySold = salesQuantitySold;
	}

	public BigDecimal getSalesAmountSold() {
		return salesAmountSold;
	}

	public void setSalesAmountSold(BigDecimal salesAmountSold) {
		this.salesAmountSold = salesAmountSold;
	}

	public Promotions getPromotions() {
		return promotions;
	}

	public void setPromotions(Promotions promotions) {
		this.promotions = promotions;
	}

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	public Customers getCustomers() {
		return customers;
	}

	public void setCustomers(Customers customers) {
		this.customers = customers;
	}

	public Channels getChannels() {
		return channels;
	}

	public void setChannels(Channels channels) {
		this.channels = channels;
	}

	public Times getTimes() {
		return times;
	}

	public void setTimes(Times times) {
		this.times = times;
	}

	public Sales(int salesId, int salesQuantitySold, BigDecimal salesAmountSold, Promotions promotions,
			Products products, Customers customers, Channels channels, Times times) {
		super();
		this.salesId = salesId;
		this.salesQuantitySold = salesQuantitySold;
		this.salesAmountSold = salesAmountSold;
		this.promotions = promotions;
		this.products = products;
		this.customers = customers;
		this.channels = channels;
		this.times = times;
	}

	@Override
	public String toString() {
		return "Sales [salesId=" + salesId + ", salesQuantitySold=" + salesQuantitySold + ", salesAmountSold="
				+ salesAmountSold + ", promotions=" + promotions + ", products=" + products + ", customers=" + customers
				+ ", channels=" + channels + ", times=" + times + "]";
	} 

	
}