package com.sales.entities;



import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TIMES")
public class Times {
	 @Id
	    @Column(name = "TIME_ID")
	    @Temporal(TemporalType.DATE)
	    private Date timeId;

	    @Column(name = "DAY_NAME", length = 9)
	    private String dayName;

	    @Column(name = "DAY_INT_IN_WEEK")
	    private int dayIntInWeek;

	    @Column(name = "DAY_INT_IN_MONTH")
	    private int dayIntInMonth;

	    @Column(name = "CALENDAR_WEEK_INT")
	    private int calendarWeekInt;

	    @Column(name = "FISCAL_WEEK_INT")
	    private int fiscalWeekInt;

	    @Column(name = "WEEK_ENDING_DAY")
	    private Date weekEndingDay;

	    @Column(name = "WEEK_ENDING_DAY_ID")
	    private int weekEndingDayId;

	    @Column(name = "CALENDAR_MONTH_INT")
	    private int calendarMonthInt;

	    @Column(name = "FISCAL_MONTH_INT")
	    private int fiscalMonthInt;

	    @Column(name = "CALENDAR_MONTH_DESC", length = 8)
	    private String calendarMonthDesc;

	    @Column(name = "CALENDAR_MONTH_ID")
	    private int calendarMonthId;

	    @Column(name = "FISCAL_MONTH_DESC", length = 8)
	    private String fiscalMonthDesc;

	    @Column(name = "FISCAL_MONTH_ID")
	    private int fiscalMonthId;

	    @Column(name = "DAYS_IN_CAL_MONTH")
	    private int daysInCalendarMonth;

	    @Column(name = "DAYS_IN_FIS_CAL_MONTH")
	    private int daysInFiscalMonth;

	    @Column(name = "END_OF_CAL_MONTH")
	    private Date endOfCalendarMonth;

	    @Column(name = "END_OF_FIS_MONTH")
	    private Date endOfFiscalMonth;

	    @Column(name = "CALENDAR_MONTH_NAME", length = 9)
	    private String calendarMonthName;

	    @Column(name = "FISCAL_MONTH_NAME", length = 9)
	    private String fiscalMonthName;

	    @Column(name = "CALENDAR_QUARTER_DESC", length = 7)
	    private String calendarQuarterDesc;

	    @Column(name = "CALENDAR_QUARTER_ID")
	    private int calendarQuarterId;

	    @Column(name = "FISCAL_QUARTER_DESC", length = 7)
	    private String fiscalQuarterDesc;

	    @Column(name = "FISCAL_QUARTER_ID")
	    private int fiscalQuarterId;

	    @Column(name = "DAYS_IN_CAL_QUARTER")
	    private int daysInCalendarQuarter;

	    @Column(name = "DAYS_IN_FIS_CAL_QUARTER")
	    private int daysInFiscalQuarter;

	    @Column(name = "END_OF_CAL_QUARTER")
	    private Date endOfCalendarQuarter;

	    @Column(name = "END_OF_FIS_CAL_QUARTER")
	    private Date endOfFiscalQuarter;

	    @Column(name = "CALENDAR_QUARTER_INT")
	    private int calendarQuarterInt;

	    @Column(name = "FISCAL_QUARTER_INT")
	    private int fiscalQuarterInt;
	    
	    @OneToMany(mappedBy = "times", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		private List<Cost> costs;
	  
	    @OneToMany(mappedBy = "times", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		private List<Sales> sales;

		

		public Times(Date timeId, String dayName, int dayIntInWeek, int dayIntInMonth, int calendarWeekInt,
				int fiscalWeekInt, Date weekEndingDay, int weekEndingDayId, int calendarMonthInt, int fiscalMonthInt,
				String calendarMonthDesc, int calendarMonthId, String fiscalMonthDesc, int fiscalMonthId,
				int daysInCalendarMonth, int daysInFiscalMonth, Date endOfCalendarMonth, Date endOfFiscalMonth,
				String calendarMonthName, String fiscalMonthName, String calendarQuarterDesc, int calendarQuarterId,
				String fiscalQuarterDesc, int fiscalQuarterId, int daysInCalendarQuarter, int daysInFiscalQuarter,
				Date endOfCalendarQuarter, Date endOfFiscalQuarter, int calendarQuarterInt, int fiscalQuarterInt,
				List<Cost> costs, List<Sales> sales) {
			super();
			this.timeId = timeId;
			this.dayName = dayName;
			this.dayIntInWeek = dayIntInWeek;
			this.dayIntInMonth = dayIntInMonth;
			this.calendarWeekInt = calendarWeekInt;
			this.fiscalWeekInt = fiscalWeekInt;
			this.weekEndingDay = weekEndingDay;
			this.weekEndingDayId = weekEndingDayId;
			this.calendarMonthInt = calendarMonthInt;
			this.fiscalMonthInt = fiscalMonthInt;
			this.calendarMonthDesc = calendarMonthDesc;
			this.calendarMonthId = calendarMonthId;
			this.fiscalMonthDesc = fiscalMonthDesc;
			this.fiscalMonthId = fiscalMonthId;
			this.daysInCalendarMonth = daysInCalendarMonth;
			this.daysInFiscalMonth = daysInFiscalMonth;
			this.endOfCalendarMonth = endOfCalendarMonth;
			this.endOfFiscalMonth = endOfFiscalMonth;
			this.calendarMonthName = calendarMonthName;
			this.fiscalMonthName = fiscalMonthName;
			this.calendarQuarterDesc = calendarQuarterDesc;
			this.calendarQuarterId = calendarQuarterId;
			this.fiscalQuarterDesc = fiscalQuarterDesc;
			this.fiscalQuarterId = fiscalQuarterId;
			this.daysInCalendarQuarter = daysInCalendarQuarter;
			this.daysInFiscalQuarter = daysInFiscalQuarter;
			this.endOfCalendarQuarter = endOfCalendarQuarter;
			this.endOfFiscalQuarter = endOfFiscalQuarter;
			this.calendarQuarterInt = calendarQuarterInt;
			this.fiscalQuarterInt = fiscalQuarterInt;
			this.costs = costs;
			this.sales = sales;
		}





	public Times() {
		super();
	}





	public Date getTimeId() {
		return timeId;
	}





	public void setTimeId(Date timeId) {
		this.timeId = timeId;
	}





	public String getDayName() {
		return dayName;
	}





	public void setDayName(String dayName) {
		this.dayName = dayName;
	}





	public int getDayIntInWeek() {
		return dayIntInWeek;
	}





	public void setDayIntInWeek(int dayIntInWeek) {
		this.dayIntInWeek = dayIntInWeek;
	}





	public int getDayIntInMonth() {
		return dayIntInMonth;
	}





	public void setDayIntInMonth(int dayIntInMonth) {
		this.dayIntInMonth = dayIntInMonth;
	}





	public int getCalendarWeekInt() {
		return calendarWeekInt;
	}





	public void setCalendarWeekInt(int calendarWeekInt) {
		this.calendarWeekInt = calendarWeekInt;
	}





	public int getFiscalWeekInt() {
		return fiscalWeekInt;
	}





	public void setFiscalWeekInt(int fiscalWeekInt) {
		this.fiscalWeekInt = fiscalWeekInt;
	}





	public Date getWeekEndingDay() {
		return weekEndingDay;
	}





	public void setWeekEndingDay(Date weekEndingDay) {
		this.weekEndingDay = weekEndingDay;
	}





	public int getWeekEndingDayId() {
		return weekEndingDayId;
	}





	public void setWeekEndingDayId(int weekEndingDayId) {
		this.weekEndingDayId = weekEndingDayId;
	}





	public int getCalendarMonthInt() {
		return calendarMonthInt;
	}





	public void setCalendarMonthInt(int calendarMonthInt) {
		this.calendarMonthInt = calendarMonthInt;
	}





	public int getFiscalMonthInt() {
		return fiscalMonthInt;
	}





	public void setFiscalMonthInt(int fiscalMonthInt) {
		this.fiscalMonthInt = fiscalMonthInt;
	}





	public String getCalendarMonthDesc() {
		return calendarMonthDesc;
	}





	public void setCalendarMonthDesc(String calendarMonthDesc) {
		this.calendarMonthDesc = calendarMonthDesc;
	}





	public int getCalendarMonthId() {
		return calendarMonthId;
	}





	public void setCalendarMonthId(int calendarMonthId) {
		this.calendarMonthId = calendarMonthId;
	}





	public String getFiscalMonthDesc() {
		return fiscalMonthDesc;
	}





	public void setFiscalMonthDesc(String fiscalMonthDesc) {
		this.fiscalMonthDesc = fiscalMonthDesc;
	}





	public int getFiscalMonthId() {
		return fiscalMonthId;
	}





	public void setFiscalMonthId(int fiscalMonthId) {
		this.fiscalMonthId = fiscalMonthId;
	}





	public int getDaysInCalendarMonth() {
		return daysInCalendarMonth;
	}





	public void setDaysInCalendarMonth(int daysInCalendarMonth) {
		this.daysInCalendarMonth = daysInCalendarMonth;
	}





	public int getDaysInFiscalMonth() {
		return daysInFiscalMonth;
	}





	public void setDaysInFiscalMonth(int daysInFiscalMonth) {
		this.daysInFiscalMonth = daysInFiscalMonth;
	}





	public Date getEndOfCalendarMonth() {
		return endOfCalendarMonth;
	}





	public void setEndOfCalendarMonth(Date endOfCalendarMonth) {
		this.endOfCalendarMonth = endOfCalendarMonth;
	}





	public Date getEndOfFiscalMonth() {
		return endOfFiscalMonth;
	}





	public void setEndOfFiscalMonth(Date endOfFiscalMonth) {
		this.endOfFiscalMonth = endOfFiscalMonth;
	}





	public String getCalendarMonthName() {
		return calendarMonthName;
	}





	public void setCalendarMonthName(String calendarMonthName) {
		this.calendarMonthName = calendarMonthName;
	}





	public String getFiscalMonthName() {
		return fiscalMonthName;
	}





	public void setFiscalMonthName(String fiscalMonthName) {
		this.fiscalMonthName = fiscalMonthName;
	}





	public String getCalendarQuarterDesc() {
		return calendarQuarterDesc;
	}





	public void setCalendarQuarterDesc(String calendarQuarterDesc) {
		this.calendarQuarterDesc = calendarQuarterDesc;
	}





	public int getCalendarQuarterId() {
		return calendarQuarterId;
	}





	public void setCalendarQuarterId(int calendarQuarterId) {
		this.calendarQuarterId = calendarQuarterId;
	}





	public String getFiscalQuarterDesc() {
		return fiscalQuarterDesc;
	}





	public void setFiscalQuarterDesc(String fiscalQuarterDesc) {
		this.fiscalQuarterDesc = fiscalQuarterDesc;
	}





	public int getFiscalQuarterId() {
		return fiscalQuarterId;
	}





	public void setFiscalQuarterId(int fiscalQuarterId) {
		this.fiscalQuarterId = fiscalQuarterId;
	}





	public int getDaysInCalendarQuarter() {
		return daysInCalendarQuarter;
	}





	public void setDaysInCalendarQuarter(int daysInCalendarQuarter) {
		this.daysInCalendarQuarter = daysInCalendarQuarter;
	}





	public int getDaysInFiscalQuarter() {
		return daysInFiscalQuarter;
	}





	public void setDaysInFiscalQuarter(int daysInFiscalQuarter) {
		this.daysInFiscalQuarter = daysInFiscalQuarter;
	}





	public Date getEndOfCalendarQuarter() {
		return endOfCalendarQuarter;
	}





	public void setEndOfCalendarQuarter(Date endOfCalendarQuarter) {
		this.endOfCalendarQuarter = endOfCalendarQuarter;
	}





	public Date getEndOfFiscalQuarter() {
		return endOfFiscalQuarter;
	}





	public void setEndOfFiscalQuarter(Date endOfFiscalQuarter) {
		this.endOfFiscalQuarter = endOfFiscalQuarter;
	}





	public int getCalendarQuarterInt() {
		return calendarQuarterInt;
	}





	public void setCalendarQuarterInt(int calendarQuarterInt) {
		this.calendarQuarterInt = calendarQuarterInt;
	}





	public int getFiscalQuarterInt() {
		return fiscalQuarterInt;
	}





	public void setFiscalQuarterInt(int fiscalQuarterInt) {
		this.fiscalQuarterInt = fiscalQuarterInt;
	}





	public List<Cost> getCosts() {
		return costs;
	}





	public void setCosts(List<Cost> costs) {
		this.costs = costs;
	}





	public List<Sales> getSales() {
		return sales;
	}





	public void setSales(List<Sales> sales) {
		this.sales = sales;
	}





	@Override
	public String toString() {
		return "Times [timeId=" + timeId + ", dayName=" + dayName + ", dayIntInWeek=" + dayIntInWeek
				+ ", dayIntInMonth=" + dayIntInMonth + ", calendarWeekInt=" + calendarWeekInt + ", fiscalWeekInt="
				+ fiscalWeekInt + ", weekEndingDay=" + weekEndingDay + ", weekEndingDayId=" + weekEndingDayId
				+ ", calendarMonthInt=" + calendarMonthInt + ", fiscalMonthInt=" + fiscalMonthInt
				+ ", calendarMonthDesc=" + calendarMonthDesc + ", calendarMonthId=" + calendarMonthId
				+ ", fiscalMonthDesc=" + fiscalMonthDesc + ", fiscalMonthId=" + fiscalMonthId + ", daysInCalendarMonth="
				+ daysInCalendarMonth + ", daysInFiscalMonth=" + daysInFiscalMonth + ", endOfCalendarMonth="
				+ endOfCalendarMonth + ", endOfFiscalMonth=" + endOfFiscalMonth + ", calendarMonthName="
				+ calendarMonthName + ", fiscalMonthName=" + fiscalMonthName + ", calendarQuarterDesc="
				+ calendarQuarterDesc + ", calendarQuarterId=" + calendarQuarterId + ", fiscalQuarterDesc="
				+ fiscalQuarterDesc + ", fiscalQuarterId=" + fiscalQuarterId + ", daysInCalendarQuarter="
				+ daysInCalendarQuarter + ", daysInFiscalQuarter=" + daysInFiscalQuarter + ", endOfCalendarQuarter="
				+ endOfCalendarQuarter + ", endOfFiscalQuarter=" + endOfFiscalQuarter + ", calendarQuarterInt="
				+ calendarQuarterInt + ", fiscalQuarterInt=" + fiscalQuarterInt + ", costs=" + costs + ", sales="
				+ sales + "]";
	}


}