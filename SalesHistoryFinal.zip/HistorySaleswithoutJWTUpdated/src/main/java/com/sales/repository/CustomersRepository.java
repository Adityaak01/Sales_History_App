package com.sales.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.sales.entities.Customers;

public interface CustomersRepository extends JpaRepository<Customers, Integer>{

	@Query("SELECT c FROM Customers c WHERE c.CustomerFirstName= ?1")

	List<Customers> findCustomersByFirstName(@Param("firstName") String CustomerFirstName);


	@Query("SELECT c FROM Customers c WHERE c.customerCity= ?1")

	List<Customers> findCustomersByCity(@Param("customerCity") String customerCity);


	@Query("SELECT c FROM Customers c WHERE c.customerIncomeLevel= ?1")

	List<Customers> findCustomersByIncome(@Param("customerIncomeLevel") String customerIncomeLevel);

	@Query("SELECT c FROM Customers c WHERE c.customerCreditLimit BETWEEN :minCreditLimit AND :maxCreditLimit")
	List<Customers> findCustomersByCreditLimitBetween(@Param("minCreditLimit") int minCreditLimit,@Param("maxCreditLimit") int maxCreditLimitint);




}


