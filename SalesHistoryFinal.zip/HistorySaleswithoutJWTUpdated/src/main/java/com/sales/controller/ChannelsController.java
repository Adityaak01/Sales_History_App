package com.sales.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.sales.entities.Channels;
import com.sales.exception.NotFoundException;
import com.sales.services.ChannelsService;

@Controller
@RequestMapping("/api/v1/Channels")
@Validated
public class ChannelsController {
	@Autowired
	ChannelsService channelsService;

	@GetMapping("/all")
	public ResponseEntity<List<Channels>> getAllChannels(){
		return new ResponseEntity<List<Channels>>(channelsService.getAllChannels(), HttpStatus.OK);
	}
	@PostMapping("/create/")
	public ResponseEntity<Void> createChannels(@Valid @RequestBody Channels channels){
		channelsService.createChannels(channels);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@DeleteMapping("/del/{channelId}")
	public ResponseEntity<Void> deleteChannels(@PathVariable("channelId") int channelId) throws NotFoundException {

		channelsService.deleteChannels(channelId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	/*
	 * saleshistoryapp database
	 * while giving input insert sales as well as cost list (empty list)
	 */
	@PutMapping("/edit/")
	public ResponseEntity<Channels> updateChannels(@Valid @RequestBody Channels channels) throws NotFoundException {
		channelsService.updateChannels(channels);
		return new ResponseEntity<Channels>(HttpStatus.OK);
	}

	/*
	 * @PutMapping("/edit/{channelId}") public ResponseEntity<Void>
	 * updateChannels(@PathVariable("channelId") int channelId) throws
	 * ChannelsNotFoundException {
	 * 
	 * channelsService.updateChannels(channelId); return new
	 * ResponseEntity<>(HttpStatus.OK);
	 * 
	 * }
	 */




}


