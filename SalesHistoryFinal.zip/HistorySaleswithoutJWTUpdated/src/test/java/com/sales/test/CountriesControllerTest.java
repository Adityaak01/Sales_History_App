/*
 * package com.sales.test;
 * 
 * import static org.junit.jupiter.api.Assertions.*; import
 * org.junit.jupiter.api.Test; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import org.mockito.MockitoAnnotations; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * com.sales.controller.CountriesController; import
 * com.sales.entities.Countries; import
 * com.sales.exception.InvalidDataException; import
 * com.sales.services.CountriesService; import
 * com.sales.exception.NotFoundException; import java.util.ArrayList; import
 * java.util.List; import java.util.Map;
 * 
 * import static org.mockito.Mockito.*;
 * 
 * public class CountriesControllerTest {
 * 
 * @Mock private CountriesService countriesService;
 * 
 * @InjectMocks private CountriesController countriesController;
 * 
 * public CountriesControllerTest() { MockitoAnnotations.initMocks(this); }
 * 
 * @Test void testGetAllCountries() { // Arrange List<Countries> countriesList =
 * new ArrayList<>(); countriesList.add(new Countries( Initialize with
 * appropriate values )); //Act
 * when(countriesService.getAllCountries()).thenReturn(countriesList);
 * ResponseEntity<List<Countries>> response =
 * countriesController.getAllCountries();
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(countriesList, response.getBody()); }
 * 
 * @Test void testCreateCountries() { // Arrange Countries countriesToCreate =
 * new Countries( Initialize with appropriate values );
 * 
 * // Act ResponseEntity<Void> response =
 * countriesController.createCountries(countriesToCreate);
 * 
 * // Assert assertEquals(HttpStatus.CREATED, response.getStatusCode()); }
 * 
 * @Test void testUpdateCountries() { // Arrange Countries countriesToUpdate =
 * new Countries( Initialize with appropriate values );
 * 
 * when(countriesService.updateCountries(countriesToUpdate)).thenReturn(
 * countriesToUpdate);
 * 
 * // Act ResponseEntity<String> response =
 * countriesController.updateCountries(countriesToUpdate);
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Record updated successfully", response.getBody()); }
 * 
 * @Test void testUpdateCountriesRecordFailed() { // Arrange Countries
 * countriesToUpdate = new Countries( Initialize with appropriate values );
 * 
 * when(countriesService.updateCountries(countriesToUpdate)).thenReturn(null);
 * 
 * // Act and Assert assertThrows(InvalidDataException.class, () -> {
 * countriesController.updateCountries(countriesToUpdate); }); }
 * 
 * @Test void testDeleteCountries() { // Arrange int countryIdToDelete = 1;
 * 
 * // Act ResponseEntity<Void> response =
 * countriesController.deleteCountries(countryIdToDelete);
 * 
 * // Assert assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode()); }
 * 
 * @Test void testGetCustomerCountByCountry() { // Arrange List<Map<String,
 * Object>> customerCountList = new ArrayList<>(); // Add customer count data to
 * the list
 * 
 * when(countriesService.getCustomerCountByCountry()).thenReturn(
 * customerCountList);
 * 
 * // Act ResponseEntity<List<Map<String, Object>>> response =
 * countriesController.getCustomerCountByCountry();
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(customerCountList, response.getBody()); }
 * 
 * @Test void testGetCustomerCountByRegion() { // Arrange String countryRegion =
 * "RegionName"; List<Object[]> customerCountList = new ArrayList<>(); // Add
 * customer count data to the list
 * 
 * when(countriesService.getCustomerCountByRegion(countryRegion)).thenReturn(
 * customerCountList);
 * 
 * // Act ResponseEntity<List<Object[]>> response =
 * countriesController.getCustomerCountByRegion(countryRegion);
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(customerCountList, response.getBody()); } }
 * 
 */