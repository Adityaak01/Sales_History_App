/*
 * package com.sales.test;
 * 
 * import com.sales.controller.ProductsController; import
 * com.sales.entities.Products; import com.sales.exception.NotFoundException;
 * import com.sales.services.ProductService;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations;
 * 
 * import org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import java.util.ArrayList; import
 * java.util.List; import static org.junit.jupiter.api.Assertions.*; import
 * static org.mockito.Mockito.*;
 * 
 * public class ProductsControllerTest {
 * 
 * @Mock private ProductService productService;
 * 
 * @InjectMocks private ProductsController productsController;
 * 
 * @BeforeEach void setUp() { MockitoAnnotations.openMocks(this); // Initialize
 * the mocks and inject them into the controller }
 * 
 * @Test void testGetAllProducts() { // Arrange List<Products> productsList =
 * new ArrayList<>(); productsList.add(new Products( Create a sample product
 * here )); when(productService.getAllProducts()).thenReturn(productsList);
 * 
 * // Act ResponseEntity<List<Products>> response =
 * productsController.getAllProducts();
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(productsList, response.getBody()); }
 * 
 * @Test void testCreateProducts() { // Arrange Products productToCreate = new
 * Products();
 * 
 * // Act ResponseEntity<Void> response =
 * productsController.createProducts(productToCreate);
 * 
 * // Assert assertEquals(HttpStatus.CREATED, response.getStatusCode()); }
 * 
 * @Test void testUpdateProducts() { // Arrange Products productToUpdate = new
 * Products( Create a sample product here );
 * 
 * // Act ResponseEntity<Products> response =
 * productsController.updateProducts(productToUpdate);
 * 
 * // Assert assertEquals(HttpStatus.CREATED, response.getStatusCode()); }
 * 
 * @Test void testDeleteProducts() { // Arrange Products productToDelete = new
 * Products( Create a sample product here );
 * 
 * // Act ResponseEntity<List<Products>> response =
 * productsController.deleteProducts(productToDelete);
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode()); }
 * 
 * @Test void testSearchProductsByCategory() throws NotFoundException { //
 * Arrange String category = "SampleCategory"; List<Products> productsList = new
 * ArrayList<>(); productsList.add(new Products( Create a sample product here
 * )); when(productService.searchProductsByCategory(category)).thenReturn(
 * productsList);
 * 
 * // Act ResponseEntity<List<Products>> response =
 * productsController.searchProductsByCategory(category);
 * 
 * // Assert assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(productsList, response.getBody()); } }
 */